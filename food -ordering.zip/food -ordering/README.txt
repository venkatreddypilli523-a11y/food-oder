================================================================================
FOODEXPRESS - COMMERCIAL ONLINE FOOD ORDERING SYSTEM
================================================================================

FoodExpress is a modern, full-featured commercial food delivery platform engineered
with high-performance HTML5, CSS3, ES6 JavaScript, PHP 8, and MySQL.

KEY FEATURES
--------------------------------------------------------------------------------
1. Customer Experience (Frontend):
   - Premium Landing Page with live hero stats, category chips, recommended kitchens
   - Split-screen modern Login & Register pages with password strength meter & demo login
   - Restaurant Discovery page with live search, filters (pure veg, ratings, free delivery, offers) & sorting
   - Restaurant Menu page with sticky category tabs, veg-only switch, and floating quick cart
   - Customization Modal (Portion size, toppings, spice level, chef special instructions)
   - Shopping Cart with real-time tax calculation, free delivery progress meter, and coupon engine
   - 4-Step Checkout with saved addresses, delivery speed selection & multiple payment modes (Card, UPI, Wallet, COD)
   - Celebratory Order Success screen with confetti animation
   - Real-Time Live Order Tracking with interactive status simulator and animated courier map
   - My Orders history with status filtering (All, Active, Completed, Cancelled) and 1-tap reordering
   - Account Profile Dashboard with saved addresses, wallet balance, and notification preferences
   - Favorites page for saved restaurants and dishes
   - Special Offers & Coupons page with 1-click apply and clipboard copy

2. Executive Admin Portal (Backend):
   - Dark modern SaaS dashboard theme
   - Executive Dashboard with 6 real-time KPI metrics, revenue charts, and order distribution
   - Restaurant Management (Add, Edit, Delete, Image URL, Rating, Delivery time, Status)
   - Food Menu Management (Add, Edit, Delete, Restaurant linking, Veg/Non-Veg, Price)
   - Order Management (Live order tracking & status updater: Pending -> Confirmed -> Preparing -> Out for Delivery -> Delivered -> Cancelled)
   - Customer Accounts Directory with order counts and total spend
   - Promotional Coupon Codes Management

PROJECT STRUCTURE
--------------------------------------------------------------------------------
online-food-order/
│
├── frontend/
│   ├── index.html              (Home Page)
│   ├── login.html              (User Login)
│   ├── register.html           (User Registration)
│   ├── restaurants.html        (Restaurant Discovery & Filters)
│   ├── menu.html               (Restaurant Menu & Category Tabs)
│   ├── food-details.html       (Food Details & Customization)
│   ├── cart.html               (Shopping Cart & Coupon Engine)
│   ├── checkout.html           (4-Step Checkout)
│   ├── order-success.html      (Order Confirmed & Confetti)
│   ├── order-tracking.html     (Real-Time GPS Map Tracking)
│   ├── orders.html             (My Orders & Reorder)
│   ├── profile.html            (User Profile & Saved Addresses)
│   ├── favorites.html          (Saved Restaurants & Dishes)
│   ├── offers.html             (Promotions & Coupons)
│   ├── css/
│   │   └── style.css           (Master Modern CSS Design System)
│   └── js/
│       ├── data.js             (Core Mock Datasets & State)
│       ├── api.js              (Intelligent Hybrid API Layer)
│       ├── app.js              (Global App Controller, Toasts & Modals)
│       ├── cart.js             (Cart, Tax & Checkout Engine)
│       └── auth.js             (Auth, Password Strength & Profile)
│
├── backend/
│   ├── config/
│   │   └── database.php        (MySQL Connection Config)
│   ├── api/
│   │   ├── restaurants.php     (Restaurants API Endpoint)
│   │   ├── foods.php           (Foods API Endpoint with Filtering)
│   │   ├── login.php           (User Login API)
│   │   ├── register.php        (User Registration API)
│   │   ├── order.php           (Order Placement API)
│   │   ├── my_orders.php       (Order History API)
│   │   └── logout.php          (Session Logout API)
│   └── admin/
│       ├── login.php           (Admin Portal Login)
│       ├── dashboard.php       (Executive Admin KPI & Charts)
│       ├── restaurants.php     (Restaurant CRUD & Status)
│       ├── foods.php           (Food Menu Item CRUD)
│       ├── orders.php          (Order Status Updates & Logistics)
│       ├── customers.php       (Customer Accounts Directory)
│       ├── coupons.php         (Coupon Code Management)
│       ├── auth.php            (Admin Session Auth Guard)
│       ├── logout.php          (Admin Logout)
│       └── admin.css           (Dark Modern Admin Stylesheet)
│
├── database/
│   └── online_food_order.sql   (Complete MySQL Database Seed)
│
└── README.txt

SETUP & RUNNING INSTRUCTIONS
--------------------------------------------------------------------------------
1. Prerequisites:
   - XAMPP (Apache + MySQL)

2. Link / Copy to htdocs:
   - Symlink or copy the project folder to:
     C:\xampp\htdocs\online-food-order\

3. Database Import:
   - Open phpMyAdmin (http://localhost/phpmyadmin/)
   - Import "database/online_food_order.sql"
   - Or run from terminal:
     mysql -u root < database/online_food_order.sql

4. Access the Application:
   - Customer Storefront:
     http://localhost/online-food-order/frontend/index.html
   - Admin Portal:
     http://localhost/online-food-order/backend/admin/login.php

DEFAULT CREDENTIALS
--------------------------------------------------------------------------------
1. Customer Demo Account:
   - Email: demo@example.com
   - Password: demo123 (or password)

2. Admin Portal:
   - Username: admin
   - Password: admin123

OFFLINE & STATIC COMPATIBILITY
--------------------------------------------------------------------------------
FoodExpress features a hybrid data architecture. If opened directly via file://
or in an environment where MySQL is momentarily stopped, it seamlessly falls back
to built-in local state so that all browsing, adding to cart, checkout, tracking,
and profile actions continue to work seamlessly without interruption.
================================================================================
