<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
require_once "../config/database.php";

$data = json_decode(file_get_contents("php://input"), true);
$name = trim($data["name"] ?? "");
$email = trim($data["email"] ?? "");
$password = $data["password"] ?? "";
$phone = trim($data["phone"] ?? "");
$address = trim($data["address"] ?? "");

if (!$name || !$email || !$password) {
    echo json_encode(["success"=>false,"message"=>"Name, email and password are required"]);
    exit;
}

$check = $conn->prepare("SELECT id FROM users WHERE email=?");
$check->bind_param("s",$email);
$check->execute();
if ($check->get_result()->num_rows > 0) {
    echo json_encode(["success"=>false,"message"=>"Email already registered"]);
    exit;
}

$hash = password_hash($password, PASSWORD_DEFAULT);
$stmt = $conn->prepare("INSERT INTO users(name,email,password,phone,address) VALUES(?,?,?,?,?)");
$stmt->bind_param("sssss",$name,$email,$hash,$phone,$address);

echo json_encode($stmt->execute()
    ? ["success"=>true,"message"=>"Registration successful"]
    : ["success"=>false,"message"=>"Registration failed"]);
?>
