<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
session_start();
require_once "../config/database.php";

$data = json_decode(file_get_contents("php://input"), true);
$email = trim($data["email"] ?? "");
$password = $data["password"] ?? "";

$stmt = $conn->prepare("SELECT id,name,email,password,phone,address FROM users WHERE email=?");
$stmt->bind_param("s",$email);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if ($user && password_verify($password,$user["password"])) {
    unset($user["password"]);
    $_SESSION["user"] = $user;
    echo json_encode(["success"=>true,"user"=>$user]);
} else {
    echo json_encode(["success"=>false,"message"=>"Invalid email or password"]);
}
?>
