<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
session_start();
require_once "../config/database.php";

$data = json_decode(file_get_contents("php://input"), true);
$items = $data["items"] ?? [];
$address = trim($data["address"] ?? "");
$paymentMethod = trim($data["payment_method"] ?? "Credit/Debit Card");
$couponCode = !empty($data["coupon_code"]) ? trim($data["coupon_code"]) : null;
$discount = floatval($data["discount"] ?? 0.00);

// Get User ID: from session or passed in JSON, or fallback to user 1
$userId = 1;
if (isset($_SESSION["user"]["id"])) {
    $userId = intval($_SESSION["user"]["id"]);
} elseif (!empty($data["user_id"])) {
    $userId = intval($data["user_id"]);
}

if (!$items || !$address) {
    echo json_encode(["success"=>false,"message"=>"Cart items and delivery address are required"]);
    exit;
}

$conn->begin_transaction();
try {
    $total = 0;
    foreach($items as $item) {
        $foodId = intval($item["food_id"]);
        $qty = max(1, intval($item["quantity"]));
        $stmt = $conn->prepare("SELECT price FROM foods WHERE id=?");
        $stmt->bind_param("i", $foodId);
        $stmt->execute();
        $food = $stmt->get_result()->fetch_assoc();
        if ($food) {
            $total += $food["price"] * $qty;
        } else {
            $total += floatval($item["price"] ?? 200) * $qty;
        }
    }

    $finalTotal = max(0, $total - $discount);
    if (!empty($data["total"])) {
        $finalTotal = floatval($data["total"]);
    }

    $stmt = $conn->prepare("INSERT INTO orders(user_id, total, status, delivery_address, payment_method, coupon_code, discount) VALUES(?, ?, 'Confirmed', ?, ?, ?, ?)");
    $stmt->bind_param("idsssd", $userId, $finalTotal, $address, $paymentMethod, $couponCode, $discount);
    $stmt->execute();
    $orderId = $conn->insert_id;

    foreach($items as $item) {
        $foodId = intval($item["food_id"]);
        $qty = max(1, intval($item["quantity"]));
        $price = floatval($item["price"] ?? 200);

        $stmt = $conn->prepare("INSERT INTO order_items(order_id, food_id, quantity, price) VALUES(?, ?, ?, ?)");
        $stmt->bind_param("iiid", $orderId, $foodId, $qty, $price);
        $stmt->execute();
    }

    $conn->commit();
    echo json_encode([
        "success" => true,
        "message" => "Order placed successfully",
        "order_id" => $orderId,
        "total" => $finalTotal
    ]);
} catch(Exception $e) {
    $conn->rollback();
    echo json_encode(["success"=>false,"message"=>$e->getMessage()]);
}
?>
