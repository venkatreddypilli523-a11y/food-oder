<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
require_once "../config/database.php";

$restaurant_id = intval($_GET["restaurant_id"] ?? 0);
$category = trim($_GET["category"] ?? "");
$search = trim($_GET["search"] ?? "");

$sql = "SELECT f.*, r.name AS restaurant_name FROM foods f JOIN restaurants r ON r.id = f.restaurant_id WHERE 1=1";
$params = [];
$types = "";

if ($restaurant_id > 0) {
    $sql .= " AND f.restaurant_id = ?";
    $params[] = $restaurant_id;
    $types .= "i";
}

if (!empty($category) && strtolower($category) !== 'all') {
    $sql .= " AND LOWER(f.category) = LOWER(?)";
    $params[] = $category;
    $types .= "s";
}

if (!empty($search)) {
    $sql .= " AND (f.name LIKE ? OR f.description LIKE ?)";
    $term = "%" . $search . "%";
    $params[] = $term;
    $params[] = $term;
    $types .= "ss";
}

$sql .= " ORDER BY f.id DESC";

if (!empty($types)) {
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query($sql);
}

$data = [];
if ($result) {
    while($row = $result->fetch_assoc()) $data[] = $row;
}
echo json_encode(["success"=>true,"foods"=>$data]);
?>
