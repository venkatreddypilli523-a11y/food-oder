<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
session_start();
require_once "../config/database.php";

$userId = 1;
if (isset($_SESSION["user"]["id"])) {
    $userId = intval($_SESSION["user"]["id"]);
} elseif (!empty($_GET["user_id"])) {
    $userId = intval($_GET["user_id"]);
}

$stmt = $conn->prepare("SELECT * FROM orders WHERE user_id=? ORDER BY id DESC");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

$data = [];
if ($result) {
    while($row = $result->fetch_assoc()) {
        $orderId = intval($row['id']);
        $iStmt = $conn->prepare("
            SELECT oi.quantity, oi.price, f.name, f.image 
            FROM order_items oi 
            JOIN foods f ON f.id = oi.food_id 
            WHERE oi.order_id = ?
        ");
        $iStmt->bind_param("i", $orderId);
        $iStmt->execute();
        $iRes = $iStmt->get_result();
        $items = [];
        if ($iRes) while($iRow = $iRes->fetch_assoc()) $items[] = $iRow;
        $row['items'] = $items;
        $data[] = $row;
    }
}

echo json_encode(["success"=>true, "orders"=>$data]);
?>
