<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
require_once "../config/database.php";

$id = intval($_GET["id"] ?? 0);
$search = trim($_GET["search"] ?? "");

if ($id > 0) {
    $stmt = $conn->prepare("SELECT * FROM restaurants WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
} elseif (!empty($search)) {
    $searchTerm = "%" . $search . "%";
    $stmt = $conn->prepare("SELECT * FROM restaurants WHERE name LIKE ? OR cuisine LIKE ? ORDER BY rating DESC");
    $stmt->bind_param("ss", $searchTerm, $searchTerm);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query("SELECT * FROM restaurants ORDER BY id DESC");
}

$data = [];
if ($result) {
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}
echo json_encode(["success"=>true,"restaurants"=>$data]);
?>
