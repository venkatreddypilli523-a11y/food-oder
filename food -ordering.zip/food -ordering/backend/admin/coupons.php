<?php
require_once "auth.php";

$msg = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $code = strtoupper(trim($_POST["code"] ?? ""));
    $discPercent = intval($_POST["discount_percent"] ?? 0);
    $discAmount = floatval($_POST["discount_amount"] ?? 0);
    $minOrder = floatval($_POST["min_order"] ?? 0);
    $desc = trim($_POST["description"] ?? "");

    if ($code) {
        $stmt = $conn->prepare("INSERT INTO coupons (code, discount_percent, discount_amount, min_order, description) VALUES (?,?,?,?,?) ON DUPLICATE KEY UPDATE discount_percent=?, discount_amount=?, min_order=?, description=?");
        $stmt->bind_param("siddsidds", $code, $discPercent, $discAmount, $minOrder, $desc, $discPercent, $discAmount, $minOrder, $desc);
        if ($stmt->execute()) {
            $msg = "Coupon '{$code}' saved successfully!";
        }
    }
}

$coupons = [];
$res = $conn->query("SELECT * FROM coupons ORDER BY id DESC");
if ($res) while($r = $res->fetch_assoc()) $coupons[] = $r;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Coupons - FoodExpress Admin</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <link rel="stylesheet" href="admin.css">
</head>
<body>

  <!-- Sidebar -->
  <aside class="admin-sidebar">
    <div class="admin-brand">
      <div class="brand-icon"><i class="fa-solid fa-utensils"></i></div>
      Food<span>Express</span>
    </div>

    <ul class="admin-nav">
      <li class="admin-nav-item"><a href="dashboard.php"><i class="fa-solid fa-chart-pie"></i> Dashboard</a></li>
      <li class="admin-nav-item"><a href="orders.php"><i class="fa-solid fa-bag-shopping"></i> Orders</a></li>
      <li class="admin-nav-item"><a href="restaurants.php"><i class="fa-solid fa-store"></i> Restaurants</a></li>
      <li class="admin-nav-item"><a href="foods.php"><i class="fa-solid fa-burger"></i> Food Items</a></li>
      <li class="admin-nav-item"><a href="customers.php"><i class="fa-solid fa-users"></i> Customers</a></li>
      <li class="admin-nav-item active"><a href="coupons.php"><i class="fa-solid fa-tags"></i> Coupons</a></li>
      <li class="admin-nav-item"><a href="../../frontend/index.html" target="_blank"><i class="fa-solid fa-arrow-up-right-from-square"></i> Storefront</a></li>
    </ul>

    <div class="admin-sidebar-footer">
      <div class="admin-nav-item">
        <a href="logout.php" style="color:var(--danger)"><i class="fa-solid fa-arrow-right-from-bracket"></i> Sign Out</a>
      </div>
    </div>
  </aside>

  <!-- Main Content -->
  <main class="admin-main">
    <header class="admin-header">
      <div class="admin-header-title">
        <h2>Promotional Coupons</h2>
      </div>
    </header>

    <div class="admin-content">
      <?php if ($msg): ?>
        <div style="background:var(--success-bg); color:var(--success); border:1px solid rgba(16,185,129,0.3); padding:12px 18px; border-radius:var(--radius-sm); margin-bottom:20px">
          <i class="fa-solid fa-circle-check"></i> <?php echo htmlspecialchars($msg); ?>
        </div>
      <?php endif; ?>

      <div style="display:grid; grid-template-columns: 1fr 1.6fr; gap:24px">
        <!-- Add Coupon Card -->
        <div class="admin-card">
          <div class="admin-card-header">
            <h3 class="admin-card-title">Create / Update Coupon</h3>
          </div>

          <form method="POST">
            <div class="admin-form-group">
              <label>Coupon Code *</label>
              <input type="text" name="code" class="admin-input" placeholder="e.g. MEGA50" required style="text-transform:uppercase">
            </div>

            <div style="display:grid; grid-template-columns:1fr 1fr; gap:14px">
              <div class="admin-form-group">
                <label>Discount %</label>
                <input type="number" name="discount_percent" class="admin-input" value="50">
              </div>
              <div class="admin-form-group">
                <label>Max Cap (₹)</label>
                <input type="number" name="discount_amount" class="admin-input" value="100">
              </div>
            </div>

            <div class="admin-form-group">
              <label>Min Order Spend (₹)</label>
              <input type="number" name="min_order" class="admin-input" value="199">
            </div>

            <div class="admin-form-group">
              <label>Offer Description</label>
              <textarea name="description" rows="2" class="admin-textarea" placeholder="50% OFF up to ₹100 on orders over ₹199"></textarea>
            </div>

            <button type="submit" class="btn-admin btn-admin-primary" style="width:100%; margin-top:12px">
              <i class="fa-solid fa-plus"></i> Save Promo Coupon
            </button>
          </form>
        </div>

        <!-- Coupons List -->
        <div class="admin-card">
          <div class="admin-card-header">
            <h3 class="admin-card-title">Active Coupons</h3>
          </div>

          <div class="admin-table-wrap">
            <table class="admin-table">
              <thead>
                <tr>
                  <th>Code</th>
                  <th>Discount</th>
                  <th>Min Order</th>
                  <th>Description</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach($coupons as $c): ?>
                  <tr>
                    <td><strong style="color:var(--primary); font-family:monospace; font-size:1.05rem"><?php echo $c['code']; ?></strong></td>
                    <td><strong style="color:#FFFFFF"><?php echo $c['discount_percent'] > 0 ? $c['discount_percent'] . '%' : '₹' . $c['discount_amount']; ?></strong></td>
                    <td>₹<?php echo $c['min_order']; ?></td>
                    <td><small style="color:var(--text-muted)"><?php echo htmlspecialchars($c['description']); ?></small></td>
                    <td><span class="status-pill delivered">Active</span></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </main>
</body>
</html>
