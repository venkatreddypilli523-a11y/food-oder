<?php
require_once "auth.php";

// Fetch Stats from MySQL
$usersCount = 0;
$restCount = 0;
$foodsCount = 0;
$ordersCount = 0;
$totalRevenue = 0;
$pendingOrders = 0;
$deliveredOrders = 0;

$uRes = $conn->query("SELECT COUNT(*) c FROM users");
if ($uRes) $usersCount = $uRes->fetch_assoc()["c"];

$rRes = $conn->query("SELECT COUNT(*) c FROM restaurants");
if ($rRes) $restCount = $rRes->fetch_assoc()["c"];

$fRes = $conn->query("SELECT COUNT(*) c FROM foods");
if ($fRes) $foodsCount = $fRes->fetch_assoc()["c"];

$oRes = $conn->query("SELECT COUNT(*) c, COALESCE(SUM(total), 0) rev FROM orders");
if ($oRes) {
    $row = $oRes->fetch_assoc();
    $ordersCount = $row["c"];
    $totalRevenue = $row["rev"];
}

$pRes = $conn->query("SELECT COUNT(*) c FROM orders WHERE status='Pending' OR status='Preparing'");
if ($pRes) $pendingOrders = $pRes->fetch_assoc()["c"];

$dRes = $conn->query("SELECT COUNT(*) c FROM orders WHERE status='Delivered'");
if ($dRes) $deliveredOrders = $dRes->fetch_assoc()["c"];

// Fetch Recent Orders
$recentOrders = [];
$ordQuery = $conn->query("SELECT o.*, u.name as user_name FROM orders o LEFT JOIN users u ON u.id = o.user_id ORDER BY o.id DESC LIMIT 10");
if ($ordQuery) {
    while($row = $ordQuery->fetch_assoc()) {
        $recentOrders[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard - FoodExpress</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <link rel="stylesheet" href="admin.css">
</head>
<body>

  <!-- Sidebar -->
  <aside class="admin-sidebar">
    <div class="admin-brand">
      <div class="brand-icon"><i class="fa-solid fa-utensils"></i></div>
      Food<span>Express</span>
    </div>

    <ul class="admin-nav">
      <li class="admin-nav-item active">
        <a href="dashboard.php"><i class="fa-solid fa-chart-pie"></i> Dashboard</a>
      </li>
      <li class="admin-nav-item">
        <a href="orders.php"><i class="fa-solid fa-bag-shopping"></i> Orders</a>
      </li>
      <li class="admin-nav-item">
        <a href="restaurants.php"><i class="fa-solid fa-store"></i> Restaurants</a>
      </li>
      <li class="admin-nav-item">
        <a href="foods.php"><i class="fa-solid fa-burger"></i> Food Items</a>
      </li>
      <li class="admin-nav-item">
        <a href="customers.php"><i class="fa-solid fa-users"></i> Customers</a>
      </li>
      <li class="admin-nav-item">
        <a href="coupons.php"><i class="fa-solid fa-tags"></i> Coupons</a>
      </li>
      <li class="admin-nav-item">
        <a href="../../frontend/index.html" target="_blank"><i class="fa-solid fa-arrow-up-right-from-square"></i> Storefront</a>
      </li>
    </ul>

    <div class="admin-sidebar-footer">
      <div class="admin-nav-item">
        <a href="logout.php" style="color:var(--danger)"><i class="fa-solid fa-arrow-right-from-bracket"></i> Sign Out</a>
      </div>
    </div>
  </aside>

  <!-- Main Content -->
  <main class="admin-main">
    <!-- Top Header -->
    <header class="admin-header">
      <div class="admin-header-title">
        <h2>Executive Dashboard</h2>
      </div>

      <div class="admin-user-info">
        <div class="admin-avatar">A</div>
        <div>
          <div style="font-weight:700; font-size:0.9rem; color:#FFFFFF">Super Admin</div>
          <small style="color:var(--text-muted); font-size:0.75rem">Root Administrator</small>
        </div>
      </div>
    </header>

    <!-- Dashboard Content -->
    <div class="admin-content">
      <!-- 6 Metrics KPI Grid -->
      <div class="admin-metrics-grid">
        <!-- Total Orders -->
        <div class="admin-metric-card">
          <div class="metric-info">
            <small>Total Orders</small>
            <h3><?php echo number_format($ordersCount); ?></h3>
            <span class="metric-badge up"><i class="fa-solid fa-arrow-up"></i> +14% this week</span>
          </div>
          <div class="metric-icon-wrap orange"><i class="fa-solid fa-bag-shopping"></i></div>
        </div>

        <!-- Total Revenue -->
        <div class="admin-metric-card">
          <div class="metric-info">
            <small>Total Revenue</small>
            <h3>₹<?php echo number_format($totalRevenue); ?></h3>
            <span class="metric-badge up"><i class="fa-solid fa-arrow-up"></i> +22.4% vs last mo</span>
          </div>
          <div class="metric-icon-wrap green"><i class="fa-solid fa-indian-rupee-sign"></i></div>
        </div>

        <!-- Customers -->
        <div class="admin-metric-card">
          <div class="metric-info">
            <small>Active Customers</small>
            <h3><?php echo number_format($usersCount); ?></h3>
            <span class="metric-badge up"><i class="fa-solid fa-arrow-up"></i> +8 new today</span>
          </div>
          <div class="metric-icon-wrap blue"><i class="fa-solid fa-users"></i></div>
        </div>

        <!-- Partner Restaurants -->
        <div class="admin-metric-card">
          <div class="metric-info">
            <small>Partner Kitchens</small>
            <h3><?php echo number_format($restCount); ?></h3>
            <span class="metric-badge up"><i class="fa-solid fa-check"></i> 100% Operational</span>
          </div>
          <div class="metric-icon-wrap yellow"><i class="fa-solid fa-store"></i></div>
        </div>

        <!-- Pending / Preparing Orders -->
        <div class="admin-metric-card">
          <div class="metric-info">
            <small>Pending & Preparing</small>
            <h3 style="color:var(--warning)"><?php echo number_format($pendingOrders); ?></h3>
            <span class="metric-badge" style="color:var(--text-muted)">Live in kitchens</span>
          </div>
          <div class="metric-icon-wrap yellow"><i class="fa-solid fa-clock-rotate-left"></i></div>
        </div>

        <!-- Delivered Orders -->
        <div class="admin-metric-card">
          <div class="metric-info">
            <small>Completed Orders</small>
            <h3 style="color:var(--success)"><?php echo number_format($deliveredOrders); ?></h3>
            <span class="metric-badge up"><i class="fa-solid fa-check-double"></i> 99.2% on-time</span>
          </div>
          <div class="metric-icon-wrap green"><i class="fa-solid fa-circle-check"></i></div>
        </div>
      </div>

      <!-- Charts Section -->
      <div class="admin-charts-grid">
        <!-- Revenue Bar Chart -->
        <div class="admin-card">
          <div class="admin-card-header">
            <h3 class="admin-card-title">Weekly Revenue Trends</h3>
            <span style="font-size:0.8rem; color:var(--text-muted)">Last 7 Days</span>
          </div>

          <div style="height: 220px; width: 100%; display:flex; align-items:flex-end; gap:16px; padding-top:20px;">
            <?php
            $days = [
              ['Mon', 1420, 45],
              ['Tue', 2180, 68],
              ['Wed', 1890, 58],
              ['Thu', 2640, 82],
              ['Fri', 3200, 95],
              ['Sat', 3850, 100],
              ['Sun', 3420, 90]
            ];
            foreach($days as $d): ?>
              <div style="flex:1; display:flex; flex-direction:column; align-items:center; gap:8px; height:100%; justify-content:flex-end">
                <span style="font-size:0.75rem; color:var(--text-muted)">₹<?php echo $d[1]; ?></span>
                <div style="width:100%; max-width:38px; height:<?php echo $d[2]; ?>%; background:linear-gradient(180deg, #FF5A36 0%, #FF3D12 100%); border-radius:6px 6px 0 0; transition:all 0.3s ease"></div>
                <span style="font-size:0.8rem; font-weight:600; color:var(--text-main)"><?php echo $d[0]; ?></span>
              </div>
            <?php endforeach; ?>
          </div>
        </div>

        <!-- Orders Breakdown Donut Chart -->
        <div class="admin-card">
          <div class="admin-card-header">
            <h3 class="admin-card-title">Orders Breakdown</h3>
          </div>

          <div style="text-align:center; padding:10px 0">
            <svg viewBox="0 0 36 36" style="width:140px; height:140px; transform:rotate(-90deg)">
              <circle cx="18" cy="18" r="15.915" fill="none" stroke="#334155" stroke-width="3.5" />
              <!-- Delivered (65%) -->
              <circle cx="18" cy="18" r="15.915" fill="none" stroke="#10B981" stroke-width="3.5" stroke-dasharray="65 35" stroke-dashoffset="0" />
              <!-- Preparing (20%) -->
              <circle cx="18" cy="18" r="15.915" fill="none" stroke="#F59E0B" stroke-width="3.5" stroke-dasharray="20 80" stroke-dashoffset="-65" />
              <!-- Out for delivery (15%) -->
              <circle cx="18" cy="18" r="15.915" fill="none" stroke="#FF5A36" stroke-width="3.5" stroke-dasharray="15 85" stroke-dashoffset="-85" />
            </svg>
          </div>

          <div style="display:flex; flex-direction:column; gap:8px; font-size:0.85rem; margin-top:10px">
            <div style="display:flex; justify-content:space-between">
              <span style="display:flex; align-items:center; gap:8px"><i class="fa-solid fa-circle" style="color:#10B981; font-size:0.6rem"></i> Delivered</span>
              <strong>65%</strong>
            </div>
            <div style="display:flex; justify-content:space-between">
              <span style="display:flex; align-items:center; gap:8px"><i class="fa-solid fa-circle" style="color:#F59E0B; font-size:0.6rem"></i> Preparing</span>
              <strong>20%</strong>
            </div>
            <div style="display:flex; justify-content:space-between">
              <span style="display:flex; align-items:center; gap:8px"><i class="fa-solid fa-circle" style="color:#FF5A36; font-size:0.6rem"></i> Out for Delivery</span>
              <strong>15%</strong>
            </div>
          </div>
        </div>
      </div>

      <!-- Recent Orders Table -->
      <div class="admin-card">
        <div class="admin-card-header">
          <h3 class="admin-card-title">Recent Live Orders</h3>
          <a href="orders.php" class="btn-admin btn-admin-outline btn-sm">View All Orders</a>
        </div>

        <div class="admin-table-wrap">
          <table class="admin-table">
            <thead>
              <tr>
                <th>Order ID</th>
                <th>Customer</th>
                <th>Delivery Address</th>
                <th>Total</th>
                <th>Payment</th>
                <th>Status</th>
                <th>Placed At</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($recentOrders)): ?>
                <tr>
                  <td colspan="8" style="text-align:center; padding:30px; color:var(--text-muted)">
                    No orders placed yet.
                  </td>
                </tr>
              <?php else: ?>
                <?php foreach($recentOrders as $ord): 
                  $status = $ord['status'] ?? 'Pending';
                  $statusClass = 'pending';
                  $sLower = strtolower($status);
                  if (str_contains($sLower, 'deliver')) $statusClass = 'delivered';
                  elseif (str_contains($sLower, 'prep')) $statusClass = 'preparing';
                  elseif (str_contains($sLower, 'out')) $statusClass = 'out-for-delivery';
                  elseif (str_contains($sLower, 'cancel')) $statusClass = 'cancelled';
                ?>
                  <tr>
                    <td><strong style="color:var(--primary); font-family:monospace">#<?php echo $ord['id']; ?></strong></td>
                    <td><strong><?php echo htmlspecialchars($ord['user_name'] ?? 'Guest Foodie'); ?></strong></td>
                    <td><span style="max-width:240px; display:inline-block; overflow:hidden; text-overflow:ellipsis; white-space:nowrap"><?php echo htmlspecialchars($ord['delivery_address']); ?></span></td>
                    <td><strong style="color:#FFFFFF">₹<?php echo number_format($ord['total']); ?></strong></td>
                    <td><small style="color:var(--text-muted)"><?php echo htmlspecialchars($ord['payment_method'] ?? 'Online'); ?></small></td>
                    <td>
                      <span class="status-pill <?php echo $statusClass; ?>">
                        <i class="fa-solid fa-circle" style="font-size:0.5rem"></i> <?php echo htmlspecialchars($status); ?>
                      </span>
                    </td>
                    <td><small style="color:var(--text-muted)"><?php echo date('M d, h:i A', strtotime($ord['created_at'])); ?></small></td>
                    <td>
                      <a href="orders.php?highlight=<?php echo $ord['id']; ?>" class="btn-admin btn-admin-outline" style="padding:4px 10px; font-size:0.75rem">
                        Manage
                      </a>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </main>

</body>
</html>
