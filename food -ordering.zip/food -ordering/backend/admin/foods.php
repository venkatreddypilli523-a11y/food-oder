<?php
require_once "auth.php";

$msg = "";
$err = "";

// Handle Delete
if (isset($_GET["delete_id"])) {
    $delId = intval($_GET["delete_id"]);
    $stmt = $conn->prepare("DELETE FROM foods WHERE id = ?");
    $stmt->bind_param("i", $delId);
    if ($stmt->execute()) {
        $msg = "Food item successfully deleted.";
    } else {
        $err = "Could not delete food item.";
    }
}

// Handle Add / Edit
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $restId = intval($_POST["restaurant_id"] ?? 1);
    $name = trim($_POST["name"] ?? "");
    $description = trim($_POST["description"] ?? "");
    $price = floatval($_POST["price"] ?? 0.00);
    $category = trim($_POST["category"] ?? "Main Course");
    $image = trim($_POST["image"] ?? "https://images.unsplash.com/photo-1546069901-ba9599a7e63c");
    $isVeg = intval($_POST["is_veg"] ?? 1);
    $editId = intval($_POST["edit_id"] ?? 0);

    if ($name && $price > 0) {
        if ($editId > 0) {
            $stmt = $conn->prepare("UPDATE foods SET restaurant_id=?, name=?, description=?, price=?, category=?, image=?, is_veg=? WHERE id=?");
            $stmt->bind_param("issdssii", $restId, $name, $description, $price, $category, $image, $isVeg, $editId);
            if ($stmt->execute()) {
                $msg = "Food item updated successfully!";
            } else {
                $err = "Update failed: " . $conn->error;
            }
        } else {
            $stmt = $conn->prepare("INSERT INTO foods (restaurant_id, name, description, price, category, image, is_veg) VALUES (?,?,?,?,?,?,?)");
            $stmt->bind_param("issdssi", $restId, $name, $description, $price, $category, $image, $isVeg);
            if ($stmt->execute()) {
                $msg = "New food item added successfully!";
            } else {
                $err = "Insertion failed: " . $conn->error;
            }
        }
    } else {
        $err = "Dish name and price are required.";
    }
}

// Fetch all restaurants for dropdown
$restaurants = [];
$rRes = $conn->query("SELECT id, name FROM restaurants ORDER BY name ASC");
if ($rRes) while($r = $rRes->fetch_assoc()) $restaurants[] = $r;

// Fetch all foods
$foods = [];
$fRes = $conn->query("SELECT f.*, r.name as restaurant_name FROM foods f LEFT JOIN restaurants r ON r.id = f.restaurant_id ORDER BY f.id DESC");
if ($fRes) while($f = $fRes->fetch_assoc()) $foods[] = $f;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Food Items - FoodExpress Admin</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <link rel="stylesheet" href="admin.css">
</head>
<body>

  <!-- Sidebar -->
  <aside class="admin-sidebar">
    <div class="admin-brand">
      <div class="brand-icon"><i class="fa-solid fa-utensils"></i></div>
      Food<span>Express</span>
    </div>

    <ul class="admin-nav">
      <li class="admin-nav-item"><a href="dashboard.php"><i class="fa-solid fa-chart-pie"></i> Dashboard</a></li>
      <li class="admin-nav-item"><a href="orders.php"><i class="fa-solid fa-bag-shopping"></i> Orders</a></li>
      <li class="admin-nav-item"><a href="restaurants.php"><i class="fa-solid fa-store"></i> Restaurants</a></li>
      <li class="admin-nav-item active"><a href="foods.php"><i class="fa-solid fa-burger"></i> Food Items</a></li>
      <li class="admin-nav-item"><a href="customers.php"><i class="fa-solid fa-users"></i> Customers</a></li>
      <li class="admin-nav-item"><a href="coupons.php"><i class="fa-solid fa-tags"></i> Coupons</a></li>
      <li class="admin-nav-item"><a href="../../frontend/index.html" target="_blank"><i class="fa-solid fa-arrow-up-right-from-square"></i> Storefront</a></li>
    </ul>

    <div class="admin-sidebar-footer">
      <div class="admin-nav-item">
        <a href="logout.php" style="color:var(--danger)"><i class="fa-solid fa-arrow-right-from-bracket"></i> Sign Out</a>
      </div>
    </div>
  </aside>

  <!-- Main Content -->
  <main class="admin-main">
    <header class="admin-header">
      <div class="admin-header-title">
        <h2>Food Menu Management</h2>
      </div>
      <button class="btn-admin btn-admin-primary" onclick="openAddModal()">
        <i class="fa-solid fa-plus"></i> Add Food Item
      </button>
    </header>

    <div class="admin-content">
      <?php if ($msg): ?>
        <div style="background:var(--success-bg); color:var(--success); border:1px solid rgba(16,185,129,0.3); padding:12px 18px; border-radius:var(--radius-sm); margin-bottom:20px">
          <i class="fa-solid fa-circle-check"></i> <?php echo htmlspecialchars($msg); ?>
        </div>
      <?php endif; ?>

      <?php if ($err): ?>
        <div style="background:var(--danger-bg); color:var(--danger); border:1px solid rgba(239,68,68,0.3); padding:12px 18px; border-radius:var(--radius-sm); margin-bottom:20px">
          <i class="fa-solid fa-triangle-exclamation"></i> <?php echo htmlspecialchars($err); ?>
        </div>
      <?php endif; ?>

      <!-- Search & Filters -->
      <div class="admin-card" style="margin-bottom:24px; padding:16px 20px">
        <div style="display:flex; justify-content:space-between; align-items:center; gap:16px; flex-wrap:wrap">
          <div style="display:flex; align-items:center; gap:10px; background:var(--admin-sidebar); border:1px solid var(--admin-border); padding:8px 14px; border-radius:var(--radius-sm); flex:1; max-width:400px">
            <i class="fa-solid fa-magnifying-glass" style="color:var(--text-muted)"></i>
            <input type="text" id="foodSearch" placeholder="Search dish name, category, restaurant..." style="background:transparent; border:none; color:#FFFFFF; width:100%; outline:none" oninput="filterFoodTable()">
          </div>
          <span style="font-size:0.85rem; color:var(--text-muted)">Total: <?php echo count($foods); ?> Dishes</span>
        </div>
      </div>

      <!-- Data Table -->
      <div class="admin-card">
        <div class="admin-table-wrap">
          <table class="admin-table" id="foodTable">
            <thead>
              <tr>
                <th>Dish</th>
                <th>Restaurant</th>
                <th>Category</th>
                <th>Type</th>
                <th>Price</th>
                <th>Rating</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($foods as $f): 
                $isVeg = !isset($f['is_veg']) || intval($f['is_veg']) === 1;
              ?>
                <tr>
                  <td>
                    <div style="display:flex; align-items:center; gap:12px">
                      <img src="<?php echo htmlspecialchars($f['image']); ?>" alt="Img" style="width:46px; height:46px; border-radius:8px; object-fit:cover">
                      <div>
                        <strong style="color:#FFFFFF; display:block"><?php echo htmlspecialchars($f['name']); ?></strong>
                        <small style="color:var(--text-muted)">ID #<?php echo $f['id']; ?></small>
                      </div>
                    </div>
                  </td>
                  <td><strong style="color:var(--primary)"><?php echo htmlspecialchars($f['restaurant_name'] ?? 'Kitchen'); ?></strong></td>
                  <td><span class="status-pill pending"><?php echo htmlspecialchars($f['category'] ?? 'Main Course'); ?></span></td>
                  <td>
                    <span style="color:<?php echo $isVeg ? '#10B981' : '#EF4444'; ?>; font-weight:700">
                      <i class="fa-solid fa-circle" style="font-size:0.6rem"></i> <?php echo $isVeg ? 'Veg' : 'Non-Veg'; ?>
                    </span>
                  </td>
                  <td><strong style="color:#FFFFFF; font-size:1.05rem">₹<?php echo number_format($f['price']); ?></strong></td>
                  <td><span style="color:#F59E0B; font-weight:700"><i class="fa-solid fa-star"></i> <?php echo $f['rating'] ?? 4.7; ?></span></td>
                  <td>
                    <div style="display:flex; gap:8px">
                      <button class="btn-admin btn-admin-outline" style="padding:4px 8px" onclick='openEditModal(<?php echo json_encode($f); ?>)'>
                        <i class="fa-solid fa-pen"></i>
                      </button>
                      <a href="foods.php?delete_id=<?php echo $f['id']; ?>" class="btn-admin btn-admin-danger" style="padding:4px 8px" onclick="return confirm('Delete this food item?');">
                        <i class="fa-solid fa-trash"></i>
                      </a>
                    </div>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </main>

  <!-- Add/Edit Food Modal -->
  <div class="admin-modal-backdrop" id="foodModalBackdrop">
    <div class="admin-modal">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px">
        <h3 id="modalHeading">Add New Food Item</h3>
        <button onclick="closeModal()" style="background:none; border:none; color:var(--text-muted); font-size:1.4rem; cursor:pointer">&times;</button>
      </div>

      <form method="POST">
        <input type="hidden" id="modalEditId" name="edit_id" value="0">

        <div class="admin-form-group">
          <label>Restaurant *</label>
          <select id="modalRestId" name="restaurant_id" class="admin-select" required>
            <?php foreach($restaurants as $r): ?>
              <option value="<?php echo $r['id']; ?>"><?php echo htmlspecialchars($r['name']); ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="admin-form-group">
          <label>Dish Name *</label>
          <input type="text" id="modalName" name="name" class="admin-input" required placeholder="e.g. Paneer Butter Masala">
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px">
          <div class="admin-form-group">
            <label>Price (₹) *</label>
            <input type="number" step="1" id="modalPrice" name="price" class="admin-input" required value="240">
          </div>
          <div class="admin-form-group">
            <label>Category</label>
            <select id="modalCategory" name="category" class="admin-select">
              <option value="Starters">Starters</option>
              <option value="Main Course">Main Course</option>
              <option value="Pizza">Pizza</option>
              <option value="Burgers">Burgers</option>
              <option value="Desserts">Desserts</option>
              <option value="Beverages">Beverages</option>
            </select>
          </div>
        </div>

        <div class="admin-form-group">
          <label>Dietary Type</label>
          <select id="modalIsVeg" name="is_veg" class="admin-select">
            <option value="1">🌱 Pure Vegetarian</option>
            <option value="0">🍖 Non-Vegetarian</option>
          </select>
        </div>

        <div class="admin-form-group">
          <label>Image URL</label>
          <input type="url" id="modalImage" name="image" class="admin-input" value="https://images.unsplash.com/photo-1546069901-ba9599a7e63c">
        </div>

        <div class="admin-form-group">
          <label>Description</label>
          <textarea id="modalDesc" name="description" rows="2" class="admin-textarea" placeholder="Delicious ingredients and taste notes..."></textarea>
        </div>

        <div style="display:flex; justify-content:flex-end; gap:12px; margin-top:24px">
          <button type="button" class="btn-admin btn-admin-outline" onclick="closeModal()">Cancel</button>
          <button type="submit" class="btn-admin btn-admin-primary">Save Dish</button>
        </div>
      </form>
    </div>
  </div>

  <script>
    const backdrop = document.getElementById("foodModalBackdrop");

    function openAddModal() {
      document.getElementById("modalHeading").textContent = "Add New Food Item";
      document.getElementById("modalEditId").value = "0";
      document.getElementById("modalName").value = "";
      document.getElementById("modalPrice").value = "200";
      document.getElementById("modalCategory").value = "Main Course";
      document.getElementById("modalIsVeg").value = "1";
      document.getElementById("modalDesc").value = "";
      backdrop.classList.add("open");
    }

    function openEditModal(f) {
      document.getElementById("modalHeading").textContent = "Edit Dish: " + f.name;
      document.getElementById("modalEditId").value = f.id;
      document.getElementById("modalRestId").value = f.restaurant_id || 1;
      document.getElementById("modalName").value = f.name || "";
      document.getElementById("modalPrice").value = f.price || 0;
      document.getElementById("modalCategory").value = f.category || "Main Course";
      document.getElementById("modalIsVeg").value = f.is_veg !== undefined ? f.is_veg : 1;
      document.getElementById("modalImage").value = f.image || "";
      document.getElementById("modalDesc").value = f.description || "";
      backdrop.classList.add("open");
    }

    function closeModal() {
      backdrop.classList.remove("open");
    }

    function filterFoodTable() {
      const q = document.getElementById("foodSearch").value.toLowerCase();
      document.querySelectorAll("#foodTable tbody tr").forEach(row => {
        const text = row.innerText.toLowerCase();
        row.style.display = text.includes(q) ? "" : "none";
      });
    }
  </script>
</body>
</html>
