<?php
require_once "auth.php";

$customers = [];
$res = $conn->query("
    SELECT u.*, COUNT(o.id) as order_count, COALESCE(SUM(o.total), 0) as total_spent 
    FROM users u 
    LEFT JOIN orders o ON o.user_id = u.id 
    GROUP BY u.id 
    ORDER BY u.id DESC
");
if ($res) {
    while($row = $res->fetch_assoc()) $customers[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Customer Directory - FoodExpress Admin</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <link rel="stylesheet" href="admin.css">
</head>
<body>

  <!-- Sidebar -->
  <aside class="admin-sidebar">
    <div class="admin-brand">
      <div class="brand-icon"><i class="fa-solid fa-utensils"></i></div>
      Food<span>Express</span>
    </div>

    <ul class="admin-nav">
      <li class="admin-nav-item"><a href="dashboard.php"><i class="fa-solid fa-chart-pie"></i> Dashboard</a></li>
      <li class="admin-nav-item"><a href="orders.php"><i class="fa-solid fa-bag-shopping"></i> Orders</a></li>
      <li class="admin-nav-item"><a href="restaurants.php"><i class="fa-solid fa-store"></i> Restaurants</a></li>
      <li class="admin-nav-item"><a href="foods.php"><i class="fa-solid fa-burger"></i> Food Items</a></li>
      <li class="admin-nav-item active"><a href="customers.php"><i class="fa-solid fa-users"></i> Customers</a></li>
      <li class="admin-nav-item"><a href="coupons.php"><i class="fa-solid fa-tags"></i> Coupons</a></li>
      <li class="admin-nav-item"><a href="../../frontend/index.html" target="_blank"><i class="fa-solid fa-arrow-up-right-from-square"></i> Storefront</a></li>
    </ul>

    <div class="admin-sidebar-footer">
      <div class="admin-nav-item">
        <a href="logout.php" style="color:var(--danger)"><i class="fa-solid fa-arrow-right-from-bracket"></i> Sign Out</a>
      </div>
    </div>
  </aside>

  <!-- Main Content -->
  <main class="admin-main">
    <header class="admin-header">
      <div class="admin-header-title">
        <h2>Customer Accounts Directory</h2>
      </div>
      <div style="font-size:0.85rem; color:var(--text-muted)">
        Total Registered: <strong><?php echo count($customers); ?></strong>
      </div>
    </header>

    <div class="admin-content">
      <div class="admin-card">
        <div class="admin-table-wrap">
          <table class="admin-table">
            <thead>
              <tr>
                <th>Customer ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Total Orders</th>
                <th>Total Spent</th>
                <th>Registered Date</th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($customers)): ?>
                <tr><td colspan="7" style="text-align:center; padding:30px; color:var(--text-muted)">No registered users found.</td></tr>
              <?php else: ?>
                <?php foreach($customers as $c): ?>
                  <tr>
                    <td><strong style="color:var(--primary); font-family:monospace">#USR-<?php echo $c['id']; ?></strong></td>
                    <td><strong style="color:#FFFFFF"><?php echo htmlspecialchars($c['name']); ?></strong></td>
                    <td><?php echo htmlspecialchars($c['email']); ?></td>
                    <td><?php echo htmlspecialchars($c['phone'] ?? '9876543210'); ?></td>
                    <td><span class="status-pill pending"><?php echo $c['order_count']; ?> Orders</span></td>
                    <td><strong style="color:var(--success)">₹<?php echo number_format($c['total_spent']); ?></strong></td>
                    <td><small style="color:var(--text-muted)"><?php echo date('M d, Y', strtotime($c['created_at'])); ?></small></td>
                  </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </main>
</body>
</html>
