<?php
session_start();
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST["username"] ?? "");
    $password = $_POST["password"] ?? "";

    if ($username === "admin" && $password === "admin123") {
        $_SESSION["admin"] = true;
        $_SESSION["admin_user"] = "Super Admin";
        header("Location: dashboard.php");
        exit;
    } else {
        $error = "Invalid administrator username or password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Portal Login - FoodExpress</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <link rel="stylesheet" href="admin.css">
</head>
<body class="admin-login-body">

  <div class="admin-login-card">
    <div style="text-align:center; margin-bottom:28px">
      <div class="admin-brand" style="justify-content:center; padding:0; border:none; margin-bottom:12px">
        <div class="brand-icon"><i class="fa-solid fa-utensils"></i></div>
        Food<span style="color:var(--primary)">Express</span>
      </div>
      <h2 style="font-size:1.4rem; color:#FFFFFF; margin-bottom:4px">Admin Control Center</h2>
      <p style="color:var(--text-muted); font-size:0.88rem">Sign in to manage restaurants, menus & live deliveries.</p>
    </div>

    <?php if ($error): ?>
      <div style="background:var(--danger-bg); color:var(--danger); border:1px solid rgba(239,68,68,0.3); padding:10px 14px; border-radius:var(--radius-sm); font-size:0.88rem; margin-bottom:20px; display:flex; align-items:center; gap:8px">
        <i class="fa-solid fa-triangle-exclamation"></i> <?php echo htmlspecialchars($error); ?>
      </div>
    <?php endif; ?>

    <form method="POST">
      <div class="admin-form-group">
        <label for="admUser">Admin Username</label>
        <input type="text" id="admUser" name="username" class="admin-input" placeholder="admin" required value="admin">
      </div>

      <div class="admin-form-group" style="margin-bottom:24px">
        <label for="admPass">Password</label>
        <input type="password" id="admPass" name="password" class="admin-input" placeholder="••••••••" required value="admin123">
      </div>

      <button type="submit" class="btn-admin btn-admin-primary" style="width:100%; padding:12px; font-size:0.95rem">
        <i class="fa-solid fa-lock"></i> Access Dashboard
      </button>
    </form>

    <!-- Quick test demo helper -->
    <div style="margin-top:24px; padding:12px; background:rgba(255,255,255,0.03); border:1px dashed var(--admin-border); border-radius:var(--radius-sm); font-size:0.8rem; display:flex; justify-content:space-between; align-items:center">
      <div>
        <span style="color:var(--text-muted)">Default Login:</span>
        <code style="color:var(--primary); font-weight:700">admin</code> / <code style="color:var(--primary); font-weight:700">admin123</code>
      </div>
      <button type="button" class="btn-admin btn-admin-outline" style="padding:4px 8px; font-size:0.75rem" onclick="fillAdminCreds()">
        Autofill
      </button>
    </div>

    <div style="text-align:center; margin-top:24px">
      <a href="../../frontend/index.html" style="color:var(--text-muted); font-size:0.85rem; text-decoration:none">
        <i class="fa-solid fa-arrow-left"></i> Return to FoodExpress Storefront
      </a>
    </div>
  </div>

  <script>
    function fillAdminCreds() {
      document.getElementById('admUser').value = 'admin';
      document.getElementById('admPass').value = 'admin123';
    }
  </script>
</body>
</html>
