<?php
require_once "auth.php";

$msg = "";
$err = "";

// Handle Delete
if (isset($_GET["delete_id"])) {
    $delId = intval($_GET["delete_id"]);
    $stmt = $conn->prepare("DELETE FROM restaurants WHERE id = ?");
    $stmt->bind_param("i", $delId);
    if ($stmt->execute()) {
        $msg = "Restaurant successfully deleted.";
    } else {
        $err = "Could not delete restaurant.";
    }
}

// Handle Add / Edit
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"] ?? "");
    $description = trim($_POST["description"] ?? "");
    $cuisine = trim($_POST["cuisine"] ?? "Multi-Cuisine");
    $rating = floatval($_POST["rating"] ?? 4.5);
    $deliveryTime = trim($_POST["delivery_time"] ?? "25-35 mins");
    $deliveryFee = floatval($_POST["delivery_fee"] ?? 0.00);
    $offer = trim($_POST["offer"] ?? "");
    $image = trim($_POST["image"] ?? "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4");
    $status = trim($_POST["status"] ?? "Open");
    $editId = intval($_POST["edit_id"] ?? 0);

    if ($name) {
        if ($editId > 0) {
            // Update
            $stmt = $conn->prepare("UPDATE restaurants SET name=?, description=?, cuisine=?, rating=?, delivery_time=?, delivery_fee=?, offer=?, image=?, status=? WHERE id=?");
            $stmt->bind_param("sssdsdsssi", $name, $description, $cuisine, $rating, $deliveryTime, $deliveryFee, $offer, $image, $status, $editId);
            if ($stmt->execute()) {
                $msg = "Restaurant updated successfully!";
            } else {
                $err = "Update failed: " . $conn->error;
            }
        } else {
            // Insert
            $stmt = $conn->prepare("INSERT INTO restaurants (name, description, cuisine, rating, delivery_time, delivery_fee, offer, image, status) VALUES (?,?,?,?,?,?,?,?,?)");
            $stmt->bind_param("sssdsdsss", $name, $description, $cuisine, $rating, $deliveryTime, $deliveryFee, $offer, $image, $status);
            if ($stmt->execute()) {
                $msg = "New restaurant added successfully!";
            } else {
                $err = "Insertion failed: " . $conn->error;
            }
        }
    } else {
        $err = "Restaurant name is required.";
    }
}

// Fetch all restaurants
$restaurants = [];
$res = $conn->query("SELECT * FROM restaurants ORDER BY id DESC");
if ($res) {
    while($r = $res->fetch_assoc()) $restaurants[] = $r;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Restaurants - FoodExpress Admin</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <link rel="stylesheet" href="admin.css">
</head>
<body>

  <!-- Sidebar -->
  <aside class="admin-sidebar">
    <div class="admin-brand">
      <div class="brand-icon"><i class="fa-solid fa-utensils"></i></div>
      Food<span>Express</span>
    </div>

    <ul class="admin-nav">
      <li class="admin-nav-item"><a href="dashboard.php"><i class="fa-solid fa-chart-pie"></i> Dashboard</a></li>
      <li class="admin-nav-item"><a href="orders.php"><i class="fa-solid fa-bag-shopping"></i> Orders</a></li>
      <li class="admin-nav-item active"><a href="restaurants.php"><i class="fa-solid fa-store"></i> Restaurants</a></li>
      <li class="admin-nav-item"><a href="foods.php"><i class="fa-solid fa-burger"></i> Food Items</a></li>
      <li class="admin-nav-item"><a href="customers.php"><i class="fa-solid fa-users"></i> Customers</a></li>
      <li class="admin-nav-item"><a href="coupons.php"><i class="fa-solid fa-tags"></i> Coupons</a></li>
      <li class="admin-nav-item"><a href="../../frontend/index.html" target="_blank"><i class="fa-solid fa-arrow-up-right-from-square"></i> Storefront</a></li>
    </ul>

    <div class="admin-sidebar-footer">
      <div class="admin-nav-item">
        <a href="logout.php" style="color:var(--danger)"><i class="fa-solid fa-arrow-right-from-bracket"></i> Sign Out</a>
      </div>
    </div>
  </aside>

  <!-- Main Content -->
  <main class="admin-main">
    <header class="admin-header">
      <div class="admin-header-title">
        <h2>Restaurant Management</h2>
      </div>
      <button class="btn-admin btn-admin-primary" onclick="openAddModal()">
        <i class="fa-solid fa-plus"></i> Add Restaurant
      </button>
    </header>

    <div class="admin-content">
      <?php if ($msg): ?>
        <div style="background:var(--success-bg); color:var(--success); border:1px solid rgba(16,185,129,0.3); padding:12px 18px; border-radius:var(--radius-sm); margin-bottom:20px">
          <i class="fa-solid fa-circle-check"></i> <?php echo htmlspecialchars($msg); ?>
        </div>
      <?php endif; ?>

      <?php if ($err): ?>
        <div style="background:var(--danger-bg); color:var(--danger); border:1px solid rgba(239,68,68,0.3); padding:12px 18px; border-radius:var(--radius-sm); margin-bottom:20px">
          <i class="fa-solid fa-triangle-exclamation"></i> <?php echo htmlspecialchars($err); ?>
        </div>
      <?php endif; ?>

      <!-- Search & Filters -->
      <div class="admin-card" style="margin-bottom:24px; padding:16px 20px">
        <div style="display:flex; justify-content:space-between; align-items:center; gap:16px; flex-wrap:wrap">
          <div style="display:flex; align-items:center; gap:10px; background:var(--admin-sidebar); border:1px solid var(--admin-border); padding:8px 14px; border-radius:var(--radius-sm); flex:1; max-width:400px">
            <i class="fa-solid fa-magnifying-glass" style="color:var(--text-muted)"></i>
            <input type="text" id="restSearch" placeholder="Search restaurant name, cuisine..." style="background:transparent; border:none; color:#FFFFFF; width:100%; outline:none" oninput="filterRestTable()">
          </div>
          <span style="font-size:0.85rem; color:var(--text-muted)">Total: <?php echo count($restaurants); ?> Kitchens</span>
        </div>
      </div>

      <!-- Data Table -->
      <div class="admin-card">
        <div class="admin-table-wrap">
          <table class="admin-table" id="restTable">
            <thead>
              <tr>
                <th>Restaurant</th>
                <th>Cuisines</th>
                <th>Rating</th>
                <th>Delivery Time</th>
                <th>Delivery Fee</th>
                <th>Offer Tag</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($restaurants as $r): ?>
                <tr>
                  <td>
                    <div style="display:flex; align-items:center; gap:12px">
                      <img src="<?php echo htmlspecialchars($r['image']); ?>" alt="Img" style="width:48px; height:48px; border-radius:8px; object-fit:cover">
                      <div>
                        <strong style="color:#FFFFFF; display:block"><?php echo htmlspecialchars($r['name']); ?></strong>
                        <small style="color:var(--text-muted)">ID #<?php echo $r['id']; ?></small>
                      </div>
                    </div>
                  </td>
                  <td><?php echo htmlspecialchars($r['cuisine'] ?? 'Multi-Cuisine'); ?></td>
                  <td><span style="color:#F59E0B; font-weight:700"><i class="fa-solid fa-star"></i> <?php echo $r['rating'] ?? 4.5; ?></span></td>
                  <td><?php echo htmlspecialchars($r['delivery_time'] ?? '25-35 mins'); ?></td>
                  <td><?php echo Number($r['delivery_fee'] ?? 0) == 0 ? '<span style="color:var(--success)">FREE</span>' : '₹' . $r['delivery_fee']; ?></td>
                  <td><small style="color:var(--primary); font-weight:600"><?php echo htmlspecialchars($r['offer'] ?? '-'); ?></small></td>
                  <td>
                    <span class="status-pill <?php echo strtolower($r['status'] ?? 'Open') === 'open' ? 'delivered' : 'cancelled'; ?>">
                      <?php echo htmlspecialchars($r['status'] ?? 'Open'); ?>
                    </span>
                  </td>
                  <td>
                    <div style="display:flex; gap:8px">
                      <button class="btn-admin btn-admin-outline" style="padding:4px 8px" onclick='openEditModal(<?php echo json_encode($r); ?>)'>
                        <i class="fa-solid fa-pen"></i>
                      </button>
                      <a href="restaurants.php?delete_id=<?php echo $r['id']; ?>" class="btn-admin btn-admin-danger" style="padding:4px 8px" onclick="return confirm('Delete this restaurant and its menu items?');">
                        <i class="fa-solid fa-trash"></i>
                      </a>
                    </div>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </main>

  <!-- Add/Edit Restaurant Modal -->
  <div class="admin-modal-backdrop" id="restModalBackdrop">
    <div class="admin-modal">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px">
        <h3 id="modalHeading">Add New Restaurant</h3>
        <button onclick="closeModal()" style="background:none; border:none; color:var(--text-muted); font-size:1.4rem; cursor:pointer">&times;</button>
      </div>

      <form method="POST">
        <input type="hidden" id="modalEditId" name="edit_id" value="0">

        <div class="admin-form-group">
          <label>Restaurant Name *</label>
          <input type="text" id="modalName" name="name" class="admin-input" required placeholder="e.g. Spice Garden">
        </div>

        <div class="admin-form-group">
          <label>Cuisine Category</label>
          <input type="text" id="modalCuisine" name="cuisine" class="admin-input" placeholder="e.g. North Indian, Biryani, Mughlai">
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px">
          <div class="admin-form-group">
            <label>Rating (1.0 - 5.0)</label>
            <input type="number" step="0.1" id="modalRating" name="rating" class="admin-input" value="4.8">
          </div>
          <div class="admin-form-group">
            <label>Delivery Time</label>
            <input type="text" id="modalTime" name="delivery_time" class="admin-input" value="25-35 mins">
          </div>
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px">
          <div class="admin-form-group">
            <label>Delivery Fee (₹)</label>
            <input type="number" id="modalFee" name="delivery_fee" class="admin-input" value="0">
          </div>
          <div class="admin-form-group">
            <label>Status</label>
            <select id="modalStatus" name="status" class="admin-select">
              <option value="Open">Open</option>
              <option value="Closed">Closed</option>
            </select>
          </div>
        </div>

        <div class="admin-form-group">
          <label>Offer Tagline</label>
          <input type="text" id="modalOffer" name="offer" class="admin-input" placeholder="e.g. 50% OFF up to ₹100">
        </div>

        <div class="admin-form-group">
          <label>Cover Image URL</label>
          <input type="url" id="modalImage" name="image" class="admin-input" value="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4">
        </div>

        <div class="admin-form-group">
          <label>Description</label>
          <textarea id="modalDesc" name="description" rows="2" class="admin-textarea" placeholder="Brief restaurant overview..."></textarea>
        </div>

        <div style="display:flex; justify-content:flex-end; gap:12px; margin-top:24px">
          <button type="button" class="btn-admin btn-admin-outline" onclick="closeModal()">Cancel</button>
          <button type="submit" class="btn-admin btn-admin-primary">Save Restaurant</button>
        </div>
      </form>
    </div>
  </div>

  <script>
    const backdrop = document.getElementById("restModalBackdrop");

    function openAddModal() {
      document.getElementById("modalHeading").textContent = "Add New Restaurant";
      document.getElementById("modalEditId").value = "0";
      document.getElementById("modalName").value = "";
      document.getElementById("modalCuisine").value = "";
      document.getElementById("modalRating").value = "4.8";
      document.getElementById("modalTime").value = "25-35 mins";
      document.getElementById("modalFee").value = "0";
      document.getElementById("modalOffer").value = "";
      document.getElementById("modalDesc").value = "";
      backdrop.classList.add("open");
    }

    function openEditModal(r) {
      document.getElementById("modalHeading").textContent = "Edit Restaurant: " + r.name;
      document.getElementById("modalEditId").value = r.id;
      document.getElementById("modalName").value = r.name || "";
      document.getElementById("modalCuisine").value = r.cuisine || "";
      document.getElementById("modalRating").value = r.rating || "4.8";
      document.getElementById("modalTime").value = r.delivery_time || "25-35 mins";
      document.getElementById("modalFee").value = r.delivery_fee || "0";
      document.getElementById("modalOffer").value = r.offer || "";
      document.getElementById("modalImage").value = r.image || "";
      document.getElementById("modalStatus").value = r.status || "Open";
      document.getElementById("modalDesc").value = r.description || "";
      backdrop.classList.add("open");
    }

    function closeModal() {
      backdrop.classList.remove("open");
    }

    function filterRestTable() {
      const q = document.getElementById("restSearch").value.toLowerCase();
      document.querySelectorAll("#restTable tbody tr").forEach(row => {
        const text = row.innerText.toLowerCase();
        row.style.display = text.includes(q) ? "" : "none";
      });
    }
  </script>
</body>
</html>
