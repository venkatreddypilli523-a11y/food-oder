<?php
require_once "auth.php";

$msg = "";
$err = "";

// Handle Status Change
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["update_status_order_id"])) {
    $orderId = intval($_POST["update_status_order_id"]);
    $newStatus = trim($_POST["new_status"] ?? "Pending");

    $stmt = $conn->prepare("UPDATE orders SET status=? WHERE id=?");
    $stmt->bind_param("si", $newStatus, $orderId);
    if ($stmt->execute()) {
        $msg = "Order #{$orderId} status changed to '{$newStatus}'!";
    } else {
        $err = "Failed to update order status.";
    }
}

// Fetch all orders with user info
$orders = [];
$res = $conn->query("
    SELECT o.*, u.name as customer_name, u.phone as customer_phone, u.email as customer_email 
    FROM orders o 
    LEFT JOIN users u ON u.id = o.user_id 
    ORDER BY o.id DESC
");
if ($res) {
    while($row = $res->fetch_assoc()) {
        // Fetch items for this order
        $itemsRes = $conn->query("
            SELECT oi.quantity, oi.price, f.name 
            FROM order_items oi 
            JOIN foods f ON f.id = oi.food_id 
            WHERE oi.order_id = " . intval($row['id'])
        );
        $items = [];
        if ($itemsRes) while($i = $itemsRes->fetch_assoc()) $items[] = $i;
        $row['items'] = $items;
        $orders[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Orders - FoodExpress Admin</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <link rel="stylesheet" href="admin.css">
</head>
<body>

  <!-- Sidebar -->
  <aside class="admin-sidebar">
    <div class="admin-brand">
      <div class="brand-icon"><i class="fa-solid fa-utensils"></i></div>
      Food<span>Express</span>
    </div>

    <ul class="admin-nav">
      <li class="admin-nav-item"><a href="dashboard.php"><i class="fa-solid fa-chart-pie"></i> Dashboard</a></li>
      <li class="admin-nav-item active"><a href="orders.php"><i class="fa-solid fa-bag-shopping"></i> Orders</a></li>
      <li class="admin-nav-item"><a href="restaurants.php"><i class="fa-solid fa-store"></i> Restaurants</a></li>
      <li class="admin-nav-item"><a href="foods.php"><i class="fa-solid fa-burger"></i> Food Items</a></li>
      <li class="admin-nav-item"><a href="customers.php"><i class="fa-solid fa-users"></i> Customers</a></li>
      <li class="admin-nav-item"><a href="coupons.php"><i class="fa-solid fa-tags"></i> Coupons</a></li>
      <li class="admin-nav-item"><a href="../../frontend/index.html" target="_blank"><i class="fa-solid fa-arrow-up-right-from-square"></i> Storefront</a></li>
    </ul>

    <div class="admin-sidebar-footer">
      <div class="admin-nav-item">
        <a href="logout.php" style="color:var(--danger)"><i class="fa-solid fa-arrow-right-from-bracket"></i> Sign Out</a>
      </div>
    </div>
  </aside>

  <!-- Main Content -->
  <main class="admin-main">
    <header class="admin-header">
      <div class="admin-header-title">
        <h2>Live Orders & Logistics</h2>
      </div>
      <div style="font-size:0.85rem; color:var(--text-muted)">
        Total Orders: <strong><?php echo count($orders); ?></strong>
      </div>
    </header>

    <div class="admin-content">
      <?php if ($msg): ?>
        <div style="background:var(--success-bg); color:var(--success); border:1px solid rgba(16,185,129,0.3); padding:12px 18px; border-radius:var(--radius-sm); margin-bottom:20px">
          <i class="fa-solid fa-circle-check"></i> <?php echo htmlspecialchars($msg); ?>
        </div>
      <?php endif; ?>

      <?php if ($err): ?>
        <div style="background:var(--danger-bg); color:var(--danger); border:1px solid rgba(239,68,68,0.3); padding:12px 18px; border-radius:var(--radius-sm); margin-bottom:20px">
          <i class="fa-solid fa-triangle-exclamation"></i> <?php echo htmlspecialchars($err); ?>
        </div>
      <?php endif; ?>

      <!-- Search & Status Filter -->
      <div class="admin-card" style="margin-bottom:24px; padding:16px 20px">
        <div style="display:flex; justify-content:space-between; align-items:center; gap:16px; flex-wrap:wrap">
          <div style="display:flex; align-items:center; gap:10px; background:var(--admin-sidebar); border:1px solid var(--admin-border); padding:8px 14px; border-radius:var(--radius-sm); flex:1; max-width:400px">
            <i class="fa-solid fa-magnifying-glass" style="color:var(--text-muted)"></i>
            <input type="text" id="orderSearch" placeholder="Search order ID, customer name, phone..." style="background:transparent; border:none; color:#FFFFFF; width:100%; outline:none" oninput="filterOrdersTable()">
          </div>

          <div style="display:flex; gap:8px">
            <select id="statusFilter" class="admin-select" style="width:auto; padding:8px 14px" onchange="filterOrdersTable()">
              <option value="all">All Statuses</option>
              <option value="pending">Pending</option>
              <option value="confirmed">Confirmed</option>
              <option value="preparing">Preparing</option>
              <option value="out for delivery">Out for Delivery</option>
              <option value="delivered">Delivered</option>
              <option value="cancelled">Cancelled</option>
            </select>
          </div>
        </div>
      </div>

      <!-- Orders Data Table -->
      <div class="admin-card">
        <div class="admin-table-wrap">
          <table class="admin-table" id="ordersTable">
            <thead>
              <tr>
                <th>Order ID</th>
                <th>Customer</th>
                <th>Dishes & Items</th>
                <th>Total</th>
                <th>Delivery Address</th>
                <th>Status</th>
                <th>Date & Time</th>
                <th>Update Status</th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($orders)): ?>
                <tr><td colspan="8" style="text-align:center; padding:30px; color:var(--text-muted)">No orders placed yet.</td></tr>
              <?php else: ?>
                <?php foreach($orders as $o): 
                  $status = $o['status'] ?? 'Pending';
                  $sLower = strtolower($status);
                  $statusClass = 'pending';
                  if (str_contains($sLower, 'deliver')) $statusClass = 'delivered';
                  elseif (str_contains($sLower, 'prep')) $statusClass = 'preparing';
                  elseif (str_contains($sLower, 'out')) $statusClass = 'out-for-delivery';
                  elseif (str_contains($sLower, 'cancel')) $statusClass = 'cancelled';
                ?>
                  <tr>
                    <td><strong style="color:var(--primary); font-family:monospace">#<?php echo $o['id']; ?></strong></td>
                    <td>
                      <strong style="color:#FFFFFF; display:block"><?php echo htmlspecialchars($o['customer_name'] ?? 'Demo User'); ?></strong>
                      <small style="color:var(--text-muted)"><?php echo htmlspecialchars($o['customer_phone'] ?? '9876543210'); ?></small>
                    </td>
                    <td>
                      <?php if (!empty($o['items'])): ?>
                        <div style="font-size:0.85rem">
                          <?php foreach($o['items'] as $item): ?>
                            <div><b><?php echo $item['quantity']; ?>x</b> <?php echo htmlspecialchars($item['name']); ?></div>
                          <?php endforeach; ?>
                        </div>
                      <?php else: ?>
                        <small style="color:var(--text-muted)">Standard Meal Combo</small>
                      <?php endif; ?>
                    </td>
                    <td><strong style="color:#FFFFFF; font-size:1.1rem">₹<?php echo number_format($o['total']); ?></strong></td>
                    <td>
                      <span style="max-width:200px; display:inline-block; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; font-size:0.85rem">
                        <?php echo htmlspecialchars($o['delivery_address']); ?>
                      </span>
                    </td>
                    <td>
                      <span class="status-pill <?php echo $statusClass; ?>">
                        <?php echo htmlspecialchars($status); ?>
                      </span>
                    </td>
                    <td><small style="color:var(--text-muted)"><?php echo date('M d, h:i A', strtotime($o['created_at'])); ?></small></td>
                    <td>
                      <!-- Inline Quick Status Changer Form -->
                      <form method="POST" style="display:flex; align-items:center; gap:6px">
                        <input type="hidden" name="update_status_order_id" value="<?php echo $o['id']; ?>">
                        <select name="new_status" class="admin-select" style="padding:4px 8px; font-size:0.8rem; width:130px">
                          <option value="Pending" <?php if($status==='Pending') echo 'selected';?>>Pending</option>
                          <option value="Confirmed" <?php if($status==='Confirmed') echo 'selected';?>>Confirmed</option>
                          <option value="Preparing" <?php if($status==='Preparing') echo 'selected';?>>Preparing</option>
                          <option value="Out for Delivery" <?php if($status==='Out for Delivery') echo 'selected';?>>Out for Delivery</option>
                          <option value="Delivered" <?php if($status==='Delivered') echo 'selected';?>>Delivered</option>
                          <option value="Cancelled" <?php if($status==='Cancelled') echo 'selected';?>>Cancelled</option>
                        </select>
                        <button type="submit" class="btn-admin btn-admin-primary" style="padding:5px 8px; font-size:0.75rem" title="Save Status">
                          <i class="fa-solid fa-check"></i>
                        </button>
                      </form>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </main>

  <script>
    function filterOrdersTable() {
      const q = document.getElementById("orderSearch").value.toLowerCase();
      const st = document.getElementById("statusFilter").value.toLowerCase();

      document.querySelectorAll("#ordersTable tbody tr").forEach(row => {
        const text = row.innerText.toLowerCase();
        const matchesQuery = text.includes(q);
        const matchesStatus = st === 'all' || text.includes(st);
        row.style.display = matchesQuery && matchesStatus ? "" : "none";
      });
    }
  </script>
</body>
</html>
