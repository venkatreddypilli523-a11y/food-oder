/**
 * FoodExpress - Core Static Dataset & State Fallbacks
 * Serves as rich mock dataset and offline fallback layer
 */

const DEFAULT_RESTAURANTS = [
  {
    id: 1,
    name: "Spice Garden",
    description: "Authentic North Indian, rich curries, fragrant tandoor breads & dum biryanis.",
    cuisine: "North Indian, Mughlai",
    rating: 4.8,
    reviews_count: 1420,
    delivery_time: "25-35 mins",
    delivery_fee: 0,
    offer: "50% OFF up to ₹100",
    image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80",
    is_featured: 1,
    status: "Open"
  },
  {
    id: 2,
    name: "Pizza House",
    description: "Handcrafted stone-baked pizzas, cheesy garlic breads and classic Italian pastas.",
    cuisine: "Italian, Pizza, Fast Food",
    rating: 4.7,
    reviews_count: 980,
    delivery_time: "20-30 mins",
    delivery_fee: 25,
    offer: "40% OFF with FE40",
    image: "https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=800&q=80",
    is_featured: 1,
    status: "Open"
  },
  {
    id: 3,
    name: "Burger Point",
    description: "Gourmet smashed burgers, crispy french fries, thick shakes and loaded snacks.",
    cuisine: "American, Burgers, Shakes",
    rating: 4.6,
    reviews_count: 850,
    delivery_time: "15-25 mins",
    delivery_fee: 0,
    offer: "FREE Fries on ₹299+",
    image: "https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=800&q=80",
    is_featured: 1,
    status: "Open"
  },
  {
    id: 4,
    name: "Royal Biryani Darbar",
    description: "Traditional Dum Biryanis cooked with pure ghee, saffron and aged basmati rice.",
    cuisine: "Biryani, Mughlai, Kebabs",
    rating: 4.9,
    reviews_count: 2100,
    delivery_time: "30-40 mins",
    delivery_fee: 30,
    offer: "FLAT ₹125 OFF",
    image: "https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=800&q=80",
    is_featured: 1,
    status: "Open"
  },
  {
    id: 5,
    name: "The Wok Express",
    description: "Sizzling wok-tossed noodles, spicy schezwan gravies, dim sums & pan-Asian bowls.",
    cuisine: "Chinese, Asian, Thai",
    rating: 4.5,
    reviews_count: 620,
    delivery_time: "25-35 mins",
    delivery_fee: 20,
    offer: "30% OFF up to ₹75",
    image: "https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&w=800&q=80",
    is_featured: 1,
    status: "Open"
  },
  {
    id: 6,
    name: "Sweet Treats Bakery",
    description: "Decadent chocolate cakes, warm brownies, fresh pastries and artisan desserts.",
    cuisine: "Desserts, Bakery, Cakes",
    rating: 4.9,
    reviews_count: 1310,
    delivery_time: "20-30 mins",
    delivery_fee: 0,
    offer: "Buy 1 Get 1 Dessert",
    image: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=800&q=80",
    is_featured: 1,
    status: "Open"
  },
  {
    id: 7,
    name: "Green Bowl Healthy Cafe",
    description: "Wholesome organic salads, protein grain bowls, cold-pressed juices and acai.",
    cuisine: "Healthy, Salads, Vegan",
    rating: 4.7,
    reviews_count: 440,
    delivery_time: "20-30 mins",
    delivery_fee: 15,
    offer: "20% OFF Healthy Eats",
    image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=800&q=80",
    is_featured: 1,
    status: "Open"
  },
  {
    id: 8,
    name: "Cafe Mocha & Sips",
    description: "Specialty espresso coffee, creamy cold brews, milkshakes and warm sandwiches.",
    cuisine: "Cafe, Beverages, Sandwiches",
    rating: 4.6,
    reviews_count: 730,
    delivery_time: "15-25 mins",
    delivery_fee: 0,
    offer: "Flat ₹50 OFF",
    image: "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=800&q=80",
    is_featured: 1,
    status: "Open"
  }
];

const DEFAULT_FOODS = [
  // Spice Garden
  {
    id: 1,
    restaurant_id: 1,
    restaurant_name: "Spice Garden",
    name: "Paneer Butter Masala",
    description: "Fresh cottage cheese cubes simmered in a luscious buttery tomato and cashew gravy.",
    price: 240,
    category: "Main Course",
    image: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=800&q=80",
    rating: 4.9,
    is_veg: 1,
    is_popular: 1
  },
  {
    id: 2,
    restaurant_id: 1,
    restaurant_name: "Spice Garden",
    name: "Dal Makhani",
    description: "Slow cooked black lentils simmered overnight with butter, fresh cream and aromatic spices.",
    price: 210,
    category: "Main Course",
    image: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80",
    rating: 4.8,
    is_veg: 1,
    is_popular: 1
  },
  {
    id: 3,
    restaurant_id: 1,
    restaurant_name: "Spice Garden",
    name: "Butter Garlic Naan",
    description: "Clay-oven baked fluffy flatbread glazed with melted salted butter and roasted garlic.",
    price: 60,
    category: "Starters",
    image: "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=800&q=80",
    rating: 4.7,
    is_veg: 1,
    is_popular: 0
  },
  {
    id: 4,
    restaurant_id: 1,
    restaurant_name: "Spice Garden",
    name: "Paneer Tikka Platter",
    description: "Marinated cottage cheese and bell peppers char-grilled in traditional tandoor.",
    price: 280,
    category: "Starters",
    image: "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format&fit=crop&w=800&q=80",
    rating: 4.9,
    is_veg: 1,
    is_popular: 1
  },
  {
    id: 5,
    restaurant_id: 1,
    restaurant_name: "Spice Garden",
    name: "Masala Dosa",
    description: "Crispy fermented crepe stuffed with spiced potato filling, served with coconut chutney and sambar.",
    price: 120,
    category: "Starters",
    image: "https://images.unsplash.com/photo-1668236543090-82eba5ee5976?auto=format&fit=crop&w=800&q=80",
    rating: 4.8,
    is_veg: 1,
    is_popular: 1
  },

  // Pizza House
  {
    id: 6,
    restaurant_id: 2,
    restaurant_name: "Pizza House",
    name: "Margherita Classico Pizza",
    description: "San Marzano tomato sauce, fresh mozzarella pearls, sweet basil and extra virgin olive oil.",
    price: 299,
    category: "Pizza",
    image: "https://images.unsplash.com/photo-1574071318508-1cdbab80d002?auto=format&fit=crop&w=800&q=80",
    rating: 4.8,
    is_veg: 1,
    is_popular: 1
  },
  {
    id: 7,
    restaurant_id: 2,
    restaurant_name: "Pizza House",
    name: "Farmhouse Garden Pizza",
    description: "Loaded with crisp bell peppers, red onions, juicy mushrooms, sweet corn and mozzarella.",
    price: 359,
    category: "Pizza",
    image: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=800&q=80",
    rating: 4.7,
    is_veg: 1,
    is_popular: 1
  },
  {
    id: 8,
    restaurant_id: 2,
    restaurant_name: "Pizza House",
    name: "Pepperoni Feast Pizza",
    description: "Zesty spiced pepperoni slices, double mozzarella cheese, and secret Italian herb blend.",
    price: 429,
    category: "Pizza",
    image: "https://images.unsplash.com/photo-1534308983496-4fabb1a015ee?auto=format&fit=crop&w=800&q=80",
    rating: 4.9,
    is_veg: 0,
    is_popular: 1
  },
  {
    id: 9,
    restaurant_id: 2,
    restaurant_name: "Pizza House",
    name: "Cheesy Stuffed Garlic Bread",
    description: "Golden toasted pull-apart bread loaded with melted mozzarella, roasted garlic butter and oregano.",
    price: 169,
    category: "Starters",
    image: "https://images.unsplash.com/photo-1619895092538-128341789043?auto=format&fit=crop&w=800&q=80",
    rating: 4.8,
    is_veg: 1,
    is_popular: 1
  },

  // Burger Point
  {
    id: 10,
    restaurant_id: 3,
    restaurant_name: "Burger Point",
    name: "Classic Cheeseburger",
    description: "Juicy grilled patty topped with aged cheddar cheese, crisp lettuce, tomato, pickles & secret sauce.",
    price: 220,
    category: "Burgers",
    image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=80",
    rating: 4.8,
    is_veg: 0,
    is_popular: 1
  },
  {
    id: 11,
    restaurant_id: 3,
    restaurant_name: "Burger Point",
    name: "Crispy Veg Supreme Burger",
    description: "Spiced golden vegetable patty, creamy mayo, fresh lettuce and slice of cheddar on toasted sesame bun.",
    price: 179,
    category: "Burgers",
    image: "https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=800&q=80",
    rating: 4.7,
    is_veg: 1,
    is_popular: 1
  },
  {
    id: 12,
    restaurant_id: 3,
    restaurant_name: "Burger Point",
    name: "Smoky BBQ Bacon Burger",
    description: "Double patty stacked with crispy smoked bacon, onion rings, cheddar and sweet hickory BBQ sauce.",
    price: 289,
    category: "Burgers",
    image: "https://images.unsplash.com/photo-1586190848861-99aa4a171e90?auto=format&fit=crop&w=800&q=80",
    rating: 4.9,
    is_veg: 0,
    is_popular: 1
  },
  {
    id: 13,
    restaurant_id: 3,
    restaurant_name: "Burger Point",
    name: "Peri Peri Seasoned Fries",
    description: "Crisp skin-on golden potatoes dusted with spicy African bird-eye chili seasoning.",
    price: 129,
    category: "Starters",
    image: "https://images.unsplash.com/photo-1576107232684-1279f3908594?auto=format&fit=crop&w=800&q=80",
    rating: 4.6,
    is_veg: 1,
    is_popular: 1
  },

  // Royal Biryani Darbar
  {
    id: 14,
    restaurant_id: 4,
    restaurant_name: "Royal Biryani Darbar",
    name: "Royal Chicken Dum Biryani",
    description: "Marinated tender chicken slow-cooked with basmati rice, saffron, fried onions and royal spices.",
    price: 340,
    category: "Main Course",
    image: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=800&q=80",
    rating: 4.9,
    is_veg: 0,
    is_popular: 1
  },
  {
    id: 15,
    restaurant_id: 4,
    restaurant_name: "Royal Biryani Darbar",
    name: "Nizami Veg Dum Biryani",
    description: "Medley of fresh garden vegetables, paneer cubes, and aromatic saffron rice sealed in clay handi.",
    price: 260,
    category: "Main Course",
    image: "https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=800&q=80",
    rating: 4.8,
    is_veg: 1,
    is_popular: 1
  },

  // Sweet Treats Bakery
  {
    id: 16,
    restaurant_id: 6,
    restaurant_name: "Sweet Treats Bakery",
    name: "Belgian Dark Chocolate Cake",
    description: "Moist layers of rich chocolate sponge filled with velvety ganache and chocolate curls.",
    price: 180,
    category: "Desserts",
    image: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=800&q=80",
    rating: 4.9,
    is_veg: 1,
    is_popular: 1
  },
  {
    id: 17,
    restaurant_id: 6,
    restaurant_name: "Sweet Treats Bakery",
    name: "Warm Fudgy Walnut Brownie",
    description: "Chewy dark cocoa brownie with toasted walnuts, served great with vanilla ice cream.",
    price: 140,
    category: "Desserts",
    image: "https://images.unsplash.com/photo-1551024601-bec78aea704b?auto=format&fit=crop&w=800&q=80",
    rating: 4.9,
    is_veg: 1,
    is_popular: 1
  },

  // Cafe Mocha & Sips
  {
    id: 18,
    restaurant_id: 8,
    restaurant_name: "Cafe Mocha & Sips",
    name: "Iced Caramel Frappe",
    description: "Chilled espresso blended with milk, sweet caramel syrup, topped with whipped cream.",
    price: 180,
    category: "Beverages",
    image: "https://images.unsplash.com/photo-1572490122747-3968b75cc699?auto=format&fit=crop&w=800&q=80",
    rating: 4.8,
    is_veg: 1,
    is_popular: 1
  },
  {
    id: 19,
    restaurant_id: 8,
    restaurant_name: "Cafe Mocha & Sips",
    name: "Oreo Overload Thick Shake",
    description: "Crushed oreo cookies blended with creamy dairy ice cream and rich chocolate fudge.",
    price: 190,
    category: "Beverages",
    image: "https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=800&q=80",
    rating: 4.9,
    is_veg: 1,
    is_popular: 1
  }
];

const DEFAULT_COUPONS = [
  {
    code: "FOOD50",
    discount_percent: 50,
    discount_amount: 100,
    min_order: 199,
    description: "50% OFF up to ₹100 on orders above ₹199",
    expiry: "31 Dec 2026"
  },
  {
    code: "FREEDEL",
    discount_percent: 0,
    discount_amount: 30,
    min_order: 149,
    description: "Free delivery on orders above ₹149",
    expiry: "31 Dec 2026"
  },
  {
    code: "WELCOME100",
    discount_percent: 0,
    discount_amount: 100,
    min_order: 299,
    description: "Flat ₹100 OFF for our lovely new foodies",
    expiry: "31 Dec 2026"
  }
];

const DEFAULT_CATEGORIES = [
  { name: "All", icon: "fa-utensils" },
  { name: "Biryani", icon: "fa-bowl-rice" },
  { name: "Pizza", icon: "fa-pizza-slice" },
  { name: "Burgers", icon: "fa-burger" },
  { name: "Starters", icon: "fa-drumstick-bite" },
  { name: "Main Course", icon: "fa-plate-wheat" },
  { name: "Desserts", icon: "fa-cake-candles" },
  { name: "Beverages", icon: "fa-mug-hot" }
];
