/**
 * FoodExpress - Intelligent API Client with Offline / LocalStorage Fallback
 */

// Determine API root dynamically
const getApiBase = () => {
  const origin = window.location.origin;
  if (origin && origin.startsWith("http")) {
    // If running under xampp or localhost
    if (window.location.pathname.includes("/online-food-order/")) {
      return origin + "/online-food-order/backend/api/";
    }
    return origin + "/backend/api/";
  }
  return "http://localhost/online-food-order/backend/api/";
};

const API_BASE = getApiBase();

async function apiCall(endpoint, options = {}) {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3500);

    const res = await fetch(API_BASE + endpoint, {
      credentials: "include",
      signal: controller.signal,
      headers: {
        "Content-Type": "application/json",
        ...(options.headers || {})
      },
      ...options
    });
    clearTimeout(timeoutId);

    if (!res.ok) throw new Error("HTTP error " + res.status);
    const data = await res.json();
    return data;
  } catch (err) {
    console.warn(`[FoodExpress API] Backend '${endpoint}' unreachable (${err.message}). Using local state.`);
    return null; // Signals fallback to local storage / static dataset
  }
}

// API Service Interface with graceful fallbacks
const FoodExpressAPI = {
  // Fetch all restaurants
  async getRestaurants() {
    const remote = await apiCall("restaurants.php");
    if (remote && remote.success && remote.restaurants && remote.restaurants.length) {
      return remote.restaurants;
    }
    return DEFAULT_RESTAURANTS;
  },

  // Fetch foods with optional restaurant_id / category filter
  async getFoods(restaurantId = null, category = null) {
    let endpoint = "foods.php";
    const params = new URLSearchParams();
    if (restaurantId) params.append("restaurant_id", restaurantId);
    if (category && category !== "All") params.append("category", category);
    if (params.toString()) endpoint += "?" + params.toString();

    const remote = await apiCall(endpoint);
    if (remote && remote.success && remote.foods && remote.foods.length) {
      return remote.foods;
    }

    // Fallback filter
    let list = [...DEFAULT_FOODS];
    if (restaurantId) {
      list = list.filter(f => Number(f.restaurant_id) === Number(restaurantId));
    }
    if (category && category !== "All") {
      list = list.filter(f => f.category.toLowerCase() === category.toLowerCase());
    }
    return list;
  },

  // User Login
  async login(email, password) {
    const remote = await apiCall("login.php", {
      method: "POST",
      body: JSON.stringify({ email, password })
    });
    if (remote) return remote;

    // Local fallback check
    if (email === "demo@example.com" && (password === "demo123" || password === "password")) {
      const demoUser = {
        id: 1,
        name: "Demo User",
        email: "demo@example.com",
        phone: "9876543210",
        address: "Flat 402, Green Valley Heights, MG Road, Bangalore"
      };
      localStorage.setItem("fe_user", JSON.stringify(demoUser));
      return { success: true, user: demoUser };
    }

    // Check localStorage registered users
    const localUsers = JSON.parse(localStorage.getItem("fe_registered_users") || "[]");
    const found = localUsers.find(u => u.email.toLowerCase() === email.toLowerCase() && u.password === password);
    if (found) {
      const userObj = { id: found.id, name: found.name, email: found.email, phone: found.phone, address: found.address };
      localStorage.setItem("fe_user", JSON.stringify(userObj));
      return { success: true, user: userObj };
    }

    return { success: false, message: "Invalid email or password. Use demo@example.com / demo123" };
  },

  // User Register
  async register(userData) {
    const remote = await apiCall("register.php", {
      method: "POST",
      body: JSON.stringify(userData)
    });
    if (remote) return remote;

    // Local fallback
    const localUsers = JSON.parse(localStorage.getItem("fe_registered_users") || "[]");
    if (localUsers.some(u => u.email.toLowerCase() === userData.email.toLowerCase())) {
      return { success: false, message: "Email is already registered" };
    }

    const newUser = {
      id: Date.now(),
      name: userData.name,
      email: userData.email,
      password: userData.password,
      phone: userData.phone || "",
      address: userData.address || ""
    };
    localUsers.push(newUser);
    localStorage.setItem("fe_registered_users", JSON.stringify(localUsers));
    return { success: true, message: "Registration successful! You can now login." };
  },

  // Place Order
  async placeOrder(orderData) {
    const remote = await apiCall("order.php", {
      method: "POST",
      body: JSON.stringify(orderData)
    });
    if (remote && remote.success) {
      // Also cache in local history
      const orderRecord = {
        id: remote.order_id || ("ORD-" + Math.floor(100000 + Math.random() * 900000)),
        total: remote.total || orderData.total,
        status: "Confirmed",
        delivery_address: orderData.address,
        payment_method: orderData.payment_method || "Credit Card",
        items: orderData.items,
        created_at: new Date().toLocaleString()
      };
      this.saveLocalOrder(orderRecord);
      return remote;
    }

    // Local fallback
    const orderId = "ORD-" + Math.floor(100000 + Math.random() * 900000);
    const orderRecord = {
      id: orderId,
      total: orderData.total,
      status: "Confirmed",
      delivery_address: orderData.address,
      payment_method: orderData.payment_method || "Credit Card",
      items: orderData.items,
      created_at: new Date().toLocaleString()
    };
    this.saveLocalOrder(orderRecord);
    return { success: true, message: "Order placed successfully!", order_id: orderId, total: orderData.total };
  },

  // Save to local order history
  saveLocalOrder(order) {
    const orders = JSON.parse(localStorage.getItem("fe_orders") || "[]");
    orders.unshift(order);
    localStorage.setItem("fe_orders", JSON.stringify(orders));
  },

  // Get My Orders
  async getMyOrders() {
    const remote = await apiCall("my_orders.php");
    if (remote && remote.success && remote.orders && remote.orders.length) {
      return remote.orders;
    }

    // Return combined or default mock orders
    let local = JSON.parse(localStorage.getItem("fe_orders") || "[]");
    if (!local.length) {
      local = [
        {
          id: 1002,
          total: 658,
          status: "Out for Delivery",
          delivery_address: "Flat 402, Green Valley Heights, MG Road, Bangalore",
          payment_method: "Credit Card",
          created_at: "Today, 02:45 PM",
          items: [{ name: "Margherita Classico Pizza", quantity: 1, price: 299 }, { name: "Farmhouse Garden Pizza", quantity: 1, price: 359 }]
        },
        {
          id: 1001,
          total: 480,
          status: "Delivered",
          delivery_address: "Flat 402, Green Valley Heights, MG Road, Bangalore",
          payment_method: "UPI",
          created_at: "Yesterday, 07:15 PM",
          items: [{ name: "Paneer Butter Masala", quantity: 2, price: 240 }]
        }
      ];
      localStorage.setItem("fe_orders", JSON.stringify(local));
    }
    return local;
  },

  // Logout
  async logout() {
    await apiCall("logout.php");
    localStorage.removeItem("fe_user");
    return { success: true };
  },

  // Current session user
  getCurrentUser() {
    return JSON.parse(localStorage.getItem("fe_user") || "null");
  }
};
