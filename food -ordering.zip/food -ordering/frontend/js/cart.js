/**
 * FoodExpress - Cart & Checkout Engine
 * Manages items, quantities, coupon codes, tax calculations & order execution
 */

const FoodExpressCart = {
  // Get cart items from localStorage
  getItems() {
    return JSON.parse(localStorage.getItem("fe_cart") || "[]");
  },

  // Save cart items to localStorage
  saveItems(items) {
    localStorage.setItem("fe_cart", JSON.stringify(items));
    FoodExpress.updateCartBadge();
    this.refreshFoodCardButtons();
  },

  // Add Item to cart
  addItem(item) {
    const items = this.getItems();
    const existingIndex = items.findIndex(i => 
      i.food_id === item.food_id && 
      (i.size || "Regular") === (item.size || "Regular") &&
      (i.addons || "") === (item.addons || "")
    );

    if (existingIndex > -1) {
      items[existingIndex].quantity += item.quantity || 1;
    } else {
      items.push({
        food_id: item.food_id,
        name: item.name,
        price: Number(item.price),
        image: item.image,
        restaurant_id: item.restaurant_id || 1,
        restaurant_name: item.restaurant_name || "FoodExpress Kitchen",
        quantity: item.quantity || 1,
        size: item.size || "Regular",
        addons: item.addons || "",
        notes: item.notes || ""
      });
    }

    this.saveItems(items);
    this.renderCartPage();
  },

  // Quick increment/decrement from card or list
  updateQuantity(foodId, delta) {
    const items = this.getItems();
    const index = items.findIndex(i => i.food_id === foodId);
    if (index === -1) return;

    items[index].quantity += delta;
    if (items[index].quantity <= 0) {
      items.splice(index, 1);
      FoodExpress.toast("info", "Item Removed", "Dish removed from your cart.");
    }

    this.saveItems(items);
    this.renderCartPage();
  },

  // Remove specific cart index
  removeItem(index) {
    const items = this.getItems();
    items.splice(index, 1);
    this.saveItems(items);
    this.renderCartPage();
    FoodExpress.toast("info", "Item Removed", "Item removed from your cart.");
  },

  // Clear all cart items
  clearCart() {
    localStorage.removeItem("fe_cart");
    localStorage.removeItem("fe_applied_coupon");
    FoodExpress.updateCartBadge();
    this.refreshFoodCardButtons();
  },

  // Coupon handling
  getAppliedCoupon() {
    return JSON.parse(localStorage.getItem("fe_applied_coupon") || "null");
  },

  applyCoupon(code) {
    if (!code) return;
    const cleanCode = code.trim().toUpperCase();
    const coupon = DEFAULT_COUPONS.find(c => c.code === cleanCode);
    const subtotal = this.calcSubtotal();

    if (!coupon) {
      FoodExpress.toast("error", "Invalid Coupon", `Coupon code "${cleanCode}" is invalid.`);
      return false;
    }

    if (subtotal < coupon.min_order) {
      FoodExpress.toast("warning", "Min Order Required", `Add ₹${coupon.min_order - subtotal} more to apply ${coupon.code}!`);
      return false;
    }

    localStorage.setItem("fe_applied_coupon", JSON.stringify(coupon));
    FoodExpress.toast("success", "Coupon Applied!", `${coupon.code} applied successfully.`);
    this.renderCartPage();
    return true;
  },

  removeCoupon() {
    localStorage.removeItem("fe_applied_coupon");
    FoodExpress.toast("info", "Coupon Removed", "Discount has been removed.");
    this.renderCartPage();
  },

  // Calculations
  calcSubtotal() {
    return this.getItems().reduce((sum, item) => sum + (item.price * item.quantity), 0);
  },

  calculateBill() {
    const subtotal = this.calcSubtotal();
    const coupon = this.getAppliedCoupon();
    let deliveryFee = subtotal >= 499 || subtotal === 0 ? 0 : 30;
    const packagingFee = subtotal > 0 ? 20 : 0;
    const tax = Math.round(subtotal * 0.05); // 5% GST

    let discount = 0;
    if (coupon && subtotal >= coupon.min_order) {
      if (coupon.code === "FREEDEL") {
        discount = deliveryFee;
        deliveryFee = 0;
      } else if (coupon.discount_percent > 0) {
        discount = Math.min((subtotal * coupon.discount_percent) / 100, coupon.discount_amount);
      } else {
        discount = coupon.discount_amount;
      }
    }

    const total = Math.max(0, subtotal + deliveryFee + packagingFee + tax - discount);

    return {
      subtotal,
      deliveryFee,
      packagingFee,
      tax,
      discount,
      total,
      coupon
    };
  },

  // Refresh on-card buttons when quantities change
  refreshFoodCardButtons() {
    const items = this.getItems();
    document.querySelectorAll("[id^='foodBtnContainer_']").forEach(container => {
      const foodId = Number(container.id.replace("foodBtnContainer_", ""));
      const match = items.find(i => i.food_id === foodId);
      if (match) {
        container.innerHTML = `
          <div class="qty-control">
            <button class="qty-btn" onclick="FoodExpressCart.updateQuantity(${foodId}, -1)">-</button>
            <span class="qty-val">${match.quantity}</span>
            <button class="qty-btn" onclick="FoodExpressCart.updateQuantity(${foodId}, 1)">+</button>
          </div>
        `;
      } else {
        container.innerHTML = `
          <button class="btn btn-primary btn-sm" onclick="FoodExpress.openFoodModal(${foodId})">
            <i class="fa-solid fa-plus"></i> Add
          </button>
        `;
      }
    });
  },

  // Render Full Cart Page (`cart.html`)
  renderCartPage() {
    const cartContainer = document.getElementById("cartItemsList");
    const summaryContainer = document.getElementById("cartSummaryArea");
    if (!cartContainer || !summaryContainer) return;

    const items = this.getItems();
    const bill = this.calculateBill();

    if (items.length === 0) {
      cartContainer.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon"><i class="fa-solid fa-basket-shopping"></i></div>
          <h3>Your cart is empty!</h3>
          <p>Explore our curated restaurants and add delicious meals to your cart.</p>
          <a href="restaurants.html" class="btn btn-primary btn-lg">Explore Restaurants</a>
        </div>
      `;
      summaryContainer.style.display = "none";
      return;
    }

    summaryContainer.style.display = "block";

    // Free delivery progress
    const neededForFree = Math.max(0, 499 - bill.subtotal);
    const progressPct = Math.min(100, Math.round((bill.subtotal / 499) * 100));

    cartContainer.innerHTML = `
      <div class="free-delivery-meter">
        <div class="meter-text">
          <i class="fa-solid fa-truck-fast"></i>
          ${neededForFree === 0 ? "You've unlocked <b>FREE Delivery</b>!" : `Add <b>₹${neededForFree}</b> more to get <b>FREE Delivery</b>!`}
        </div>
        <div class="meter-progress-track">
          <div class="meter-progress-fill" style="width: ${progressPct}%"></div>
        </div>
      </div>

      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px">
        <h3 style="font-size:1.25rem">${items.length} Item${items.length > 1 ? 's' : ''} in Cart</h3>
        <button class="btn btn-outline btn-sm" onclick="FoodExpressCart.clearCart(); FoodExpressCart.renderCartPage();">
          <i class="fa-regular fa-trash-can"></i> Clear Cart
        </button>
      </div>

      ${items.map((item, idx) => `
        <div class="cart-item-row">
          <img src="${item.image}" alt="${item.name}" class="cart-item-img" onerror="this.src='https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80'">
          <div class="cart-item-info">
            <h4 class="cart-item-name">${item.name}</h4>
            <div class="cart-item-customization">
              ${item.size ? `<span>Size: ${item.size}</span>` : ''}
              ${item.addons ? ` • <span>Addons: ${item.addons}</span>` : ''}
            </div>
            <div class="cart-item-price">₹${item.price} each</div>
          </div>
          <div class="qty-control">
            <button class="qty-btn" onclick="FoodExpressCart.updateQuantity(${item.food_id}, -1)">-</button>
            <span class="qty-val">${item.quantity}</span>
            <button class="qty-btn" onclick="FoodExpressCart.updateQuantity(${item.food_id}, 1)">+</button>
          </div>
          <div class="cart-item-total">₹${item.price * item.quantity}</div>
          <button class="btn-remove-item" onclick="FoodExpressCart.removeItem(${idx})" title="Remove Item">
            <i class="fa-solid fa-xmark"></i>
          </button>
        </div>
      `).join('')}

      <div style="margin-top:24px; padding-top:16px; border-top:1px solid var(--border-light); display:flex; justify-content:space-between; align-items:center">
        <a href="restaurants.html" class="view-all-link"><i class="fa-solid fa-arrow-left"></i> Add More Food Items</a>
      </div>
    `;

    summaryContainer.innerHTML = `
      <div class="order-summary-card">
        <h3 class="order-summary-title">Order Summary</h3>

        <div class="coupon-box-wrap">
          <div class="form-label">Have a Promo Code?</div>
          ${bill.coupon ? `
            <div class="coupon-applied-alert">
              <span><i class="fa-solid fa-tag"></i> <b>${bill.coupon.code}</b> applied</span>
              <button onclick="FoodExpressCart.removeCoupon()" style="background:none; border:none; cursor:pointer; color:var(--success); font-weight:700">&times;</button>
            </div>
          ` : `
            <div class="coupon-input-group">
              <input type="text" id="couponCodeInput" class="coupon-input" placeholder="Enter coupon code (e.g. FOOD50)">
              <button class="btn btn-primary btn-sm" onclick="FoodExpressCart.applyCoupon(document.getElementById('couponCodeInput').value)">Apply</button>
            </div>
            <div style="display:flex; gap:6px; flex-wrap:wrap; margin-bottom:18px">
              <span class="copy-btn" onclick="FoodExpressCart.applyCoupon('FOOD50')">FOOD50</span>
              <span class="copy-btn" onclick="FoodExpressCart.applyCoupon('FREEDEL')">FREEDEL</span>
              <span class="copy-btn" onclick="FoodExpressCart.applyCoupon('WELCOME100')">WELCOME100</span>
            </div>
          `}
        </div>

        <div class="summary-row">
          <span>Item Total</span>
          <span>₹${bill.subtotal}</span>
        </div>
        <div class="summary-row">
          <span>Delivery Partner Fee</span>
          <span>${bill.deliveryFee === 0 ? '<strong style="color:var(--success)">FREE</strong>' : '₹' + bill.deliveryFee}</span>
        </div>
        <div class="summary-row">
          <span>Restaurant Packaging</span>
          <span>₹${bill.packagingFee}</span>
        </div>
        <div class="summary-row">
          <span>Govt Taxes (GST 5%)</span>
          <span>₹${bill.tax}</span>
        </div>
        ${bill.discount > 0 ? `
          <div class="summary-row discount">
            <span>Coupon Discount</span>
            <span>- ₹${bill.discount}</span>
          </div>
        ` : ''}

        <div class="summary-row total">
          <span>To Pay</span>
          <span>₹${bill.total}</span>
        </div>

        <div style="margin-top:24px">
          <a href="checkout.html" class="btn btn-primary btn-lg" style="width:100%">
            Proceed to Checkout <i class="fa-solid fa-arrow-right"></i>
          </a>
        </div>

        <div style="margin-top:18px; text-align:center; font-size:0.8rem; color:var(--text-light); display:flex; align-items:center; justify-content:center; gap:8px">
          <i class="fa-solid fa-shield-halved" style="color:var(--success)"></i> Safe and Secure Payment Guaranteed
        </div>
      </div>
    `;
  },

  // Checkout Page Controller (`checkout.html`)
  setupCheckoutPage() {
    const summaryEl = document.getElementById("checkoutOrderSummary");
    if (!summaryEl) return;

    const items = this.getItems();
    if (items.length === 0) {
      window.location.href = "cart.html";
      return;
    }

    const bill = this.calculateBill();
    summaryEl.innerHTML = `
      <div class="order-summary-card">
        <h3 class="order-summary-title">Your Order</h3>
        <div style="max-height:220px; overflow-y:auto; margin-bottom:16px">
          ${items.map(i => `
            <div style="display:flex; justify-content:space-between; margin-bottom:10px; font-size:0.9rem">
              <span><b>${i.quantity}x</b> ${i.name}</span>
              <span style="font-weight:600">₹${i.price * i.quantity}</span>
            </div>
          `).join('')}
        </div>

        <div class="summary-row"><span>Items Subtotal</span><span>₹${bill.subtotal}</span></div>
        <div class="summary-row"><span>Delivery Fee</span><span>${bill.deliveryFee === 0 ? 'FREE' : '₹' + bill.deliveryFee}</span></div>
        <div class="summary-row"><span>Taxes & Charges</span><span>₹${bill.tax + bill.packagingFee}</span></div>
        ${bill.discount > 0 ? `<div class="summary-row discount"><span>Discount Savings</span><span>-₹${bill.discount}</span></div>` : ''}

        <div class="summary-row total">
          <span>Total Payable</span>
          <span>₹${bill.total}</span>
        </div>

        <button id="btnPlaceOrder" class="btn btn-primary btn-lg" style="width:100%; margin-top:24px" onclick="FoodExpressCart.submitOrder()">
          Place Order • ₹${bill.total}
        </button>
      </div>
    `;

    // Populate user details if logged in
    const user = FoodExpressAPI.getCurrentUser();
    if (user) {
      const nameInput = document.getElementById("chkFullName");
      const phoneInput = document.getElementById("chkPhone");
      const addressInput = document.getElementById("chkAddress");
      if (nameInput && !nameInput.value) nameInput.value = user.name || "";
      if (phoneInput && !phoneInput.value) phoneInput.value = user.phone || "";
      if (addressInput && !addressInput.value) addressInput.value = user.address || "";
    }
  },

  // Submit Order from checkout
  async submitOrder() {
    const btn = document.getElementById("btnPlaceOrder");
    const name = document.getElementById("chkFullName")?.value.trim();
    const phone = document.getElementById("chkPhone")?.value.trim();
    const address = document.getElementById("chkAddress")?.value.trim();
    const city = document.getElementById("chkCity")?.value.trim() || "Bangalore";
    const paymentRadio = document.querySelector('input[name="paymentMethod"]:checked');
    const paymentMethod = paymentRadio ? paymentRadio.value : "Credit/Debit Card";

    if (!name || !phone || !address) {
      FoodExpress.toast("error", "Missing Details", "Please fill in your delivery name, phone, and complete address.");
      return;
    }

    if (btn) {
      btn.disabled = true;
      btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> Processing Order...`;
    }

    const items = this.getItems();
    const bill = this.calculateBill();
    const fullAddress = `${address}, ${city} - Phone: ${phone} (Recipient: ${name})`;

    const orderPayload = {
      items: items.map(i => ({ food_id: i.food_id, quantity: i.quantity, price: i.price, name: i.name })),
      address: fullAddress,
      total: bill.total,
      payment_method: paymentMethod,
      coupon_code: bill.coupon ? bill.coupon.code : null,
      discount: bill.discount
    };

    const result = await FoodExpressAPI.placeOrder(orderPayload);

    if (result && result.success) {
      // Store current active order details for the confirmation page
      const confirmedOrder = {
        orderId: result.order_id,
        total: bill.total,
        restaurantName: items[0]?.restaurant_name || "FoodExpress Premier Kitchen",
        address: fullAddress,
        items: items,
        paymentMethod: paymentMethod,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      sessionStorage.setItem("fe_last_order", JSON.stringify(confirmedOrder));

      this.clearCart();
      window.location.href = `order-success.html?order_id=${result.order_id}`;
    } else {
      if (btn) {
        btn.disabled = false;
        btn.innerHTML = `Place Order • ₹${bill.total}`;
      }
      FoodExpress.toast("error", "Order Failed", result?.message || "Could not process order. Please try again.");
    }
  }
};
