/**
 * FoodExpress - Authentication & Profile Controller
 * Manages Login, Register, Password Strength, Visibility, and Profile Management
 */

const FoodExpressAuth = {
  // Toggle password visibility
  togglePasswordVisibility(inputId, toggleBtn) {
    const input = document.getElementById(inputId);
    if (!input) return;

    if (input.type === "password") {
      input.type = "text";
      toggleBtn.innerHTML = '<i class="fa-regular fa-eye-slash"></i>';
    } else {
      input.type = "password";
      toggleBtn.innerHTML = '<i class="fa-regular fa-eye"></i>';
    }
  },

  // Password strength meter
  checkPasswordStrength(password) {
    const bar = document.getElementById("strengthBar");
    const text = document.getElementById("strengthText");
    if (!bar || !text) return;

    let score = 0;
    if (password.length >= 6) score += 25;
    if (password.length >= 10) score += 25;
    if (/[A-Z]/.test(password)) score += 25;
    if (/[0-9]/.test(password) || /[^A-Za-z0-9]/.test(password)) score += 25;

    bar.style.width = score + "%";

    if (score <= 25) {
      bar.style.backgroundColor = "var(--danger)";
      text.textContent = "Weak password";
      text.style.color = "var(--danger)";
    } else if (score <= 50) {
      bar.style.backgroundColor = "var(--warning)";
      text.textContent = "Fair password";
      text.style.color = "var(--warning)";
    } else if (score <= 75) {
      bar.style.backgroundColor = "#3B82F6";
      text.textContent = "Good password";
      text.style.color = "#3B82F6";
    } else {
      bar.style.backgroundColor = "var(--success)";
      text.textContent = "Strong password";
      text.style.color = "var(--success)";
    }
  },

  // Autofill demo credentials
  autofillDemo() {
    const emailEl = document.getElementById("loginEmail");
    const passEl = document.getElementById("loginPassword");
    if (emailEl && passEl) {
      emailEl.value = "demo@example.com";
      passEl.value = "demo123";
      FoodExpress.toast("info", "Demo Credentials Loaded", "Click 'Sign In' to proceed.");
    }
  },

  // Login Form Submission
  async handleLogin(event) {
    event.preventDefault();
    const email = document.getElementById("loginEmail")?.value.trim();
    const password = document.getElementById("loginPassword")?.value;
    const btn = document.getElementById("btnLoginSubmit");

    if (!email || !password) {
      FoodExpress.toast("error", "Missing Credentials", "Please enter your email and password.");
      return;
    }

    if (btn) {
      btn.disabled = true;
      btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> Signing in...`;
    }

    const result = await FoodExpressAPI.login(email, password);

    if (result && result.success) {
      FoodExpress.toast("success", "Welcome Back!", `Logged in as ${result.user.name}`);
      setTimeout(() => {
        const urlParams = new URLSearchParams(window.location.search);
        const redirect = urlParams.get("redirect") || "index.html";
        window.location.href = redirect;
      }, 700);
    } else {
      if (btn) {
        btn.disabled = false;
        btn.innerHTML = `Sign In <i class="fa-solid fa-arrow-right"></i>`;
      }
      FoodExpress.toast("error", "Login Failed", result?.message || "Invalid email or password.");
    }
  },

  // Registration Form Submission
  async handleRegister(event) {
    event.preventDefault();
    const name = document.getElementById("regName")?.value.trim();
    const email = document.getElementById("regEmail")?.value.trim();
    const phone = document.getElementById("regPhone")?.value.trim();
    const address = document.getElementById("regAddress")?.value.trim();
    const password = document.getElementById("regPassword")?.value;
    const confirmPassword = document.getElementById("regConfirmPassword")?.value;
    const terms = document.getElementById("regTerms")?.checked;
    const btn = document.getElementById("btnRegisterSubmit");

    if (!name || !email || !password) {
      FoodExpress.toast("error", "Missing Fields", "Please complete all required fields.");
      return;
    }

    if (password !== confirmPassword) {
      FoodExpress.toast("error", "Password Mismatch", "Passwords do not match.");
      return;
    }

    if (!terms) {
      FoodExpress.toast("warning", "Terms & Conditions", "Please agree to the Terms of Service.");
      return;
    }

    if (btn) {
      btn.disabled = true;
      btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> Creating Account...`;
    }

    const result = await FoodExpressAPI.register({
      name,
      email,
      phone,
      address,
      password
    });

    if (result && result.success) {
      FoodExpress.toast("success", "Account Created!", "Registration successful. Please log in.");
      setTimeout(() => {
        window.location.href = "login.html";
      }, 900);
    } else {
      if (btn) {
        btn.disabled = false;
        btn.innerHTML = `Create Account <i class="fa-solid fa-arrow-right"></i>`;
      }
      FoodExpress.toast("error", "Registration Failed", result?.message || "Failed to register account.");
    }
  },

  // Setup Profile Page (`profile.html`)
  setupProfilePage() {
    const user = FoodExpressAPI.getCurrentUser();
    if (!user) {
      window.location.href = "login.html?redirect=profile.html";
      return;
    }

    // Set user info
    const nameEls = document.querySelectorAll(".profileUserName");
    const emailEls = document.querySelectorAll(".profileUserEmail");
    const phoneInput = document.getElementById("profPhone");
    const nameInput = document.getElementById("profName");
    const addressInput = document.getElementById("profAddress");

    nameEls.forEach(el => el.textContent = user.name);
    emailEls.forEach(el => el.textContent = user.email);

    if (nameInput) nameInput.value = user.name || "";
    if (phoneInput) phoneInput.value = user.phone || "";
    if (addressInput) addressInput.value = user.address || "";
  },

  // Save profile changes
  saveProfile(event) {
    event.preventDefault();
    const user = FoodExpressAPI.getCurrentUser();
    if (!user) return;

    user.name = document.getElementById("profName")?.value.trim() || user.name;
    user.phone = document.getElementById("profPhone")?.value.trim() || user.phone;
    user.address = document.getElementById("profAddress")?.value.trim() || user.address;

    localStorage.setItem("fe_user", JSON.stringify(user));
    FoodExpress.toast("success", "Profile Updated", "Your changes have been saved.");
    this.setupProfilePage();
  }
};
