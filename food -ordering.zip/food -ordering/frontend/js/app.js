/**
 * FoodExpress - Core Frontend Application Controller
 * Handles Navigation, Modals, Toasts, Cart Sync, Card Templates, Favorites
 */

const FoodExpress = {
  // Toast Notification System
  toast(type = "info", title = "", message = "") {
    let container = document.getElementById("toastContainer");
    if (!container) {
      container = document.createElement("div");
      container.id = "toastContainer";
      container.className = "toast-container";
      document.body.appendChild(container);
    }

    const icons = {
      success: "fa-circle-check",
      error: "fa-circle-exclamation",
      warning: "fa-triangle-exclamation",
      info: "fa-circle-info"
    };

    const toast = document.createElement("div");
    toast.className = `toast ${type}`;
    toast.innerHTML = `
      <div class="toast-icon">
        <i class="fa-solid ${icons[type] || icons.info}"></i>
      </div>
      <div class="toast-content">
        <div class="toast-title">${title}</div>
        <div class="toast-msg">${message}</div>
      </div>
    `;

    container.appendChild(toast);
    requestAnimationFrame(() => toast.classList.add("show"));

    setTimeout(() => {
      toast.classList.remove("show");
      setTimeout(() => toast.remove(), 400);
    }, 3800);
  },

  // Update Cart badge in Nav
  updateCartBadge() {
    const cart = JSON.parse(localStorage.getItem("fe_cart") || "[]");
    const count = cart.reduce((sum, item) => sum + item.quantity, 0);
    const badges = document.querySelectorAll(".cart-badge, #cartCount");
    badges.forEach(b => {
      b.textContent = count;
      b.style.display = count > 0 ? "inline-flex" : "none";
    });
  },

  // Setup Navbar & User Profile Dropdown
  setupNavbar() {
    const user = FoodExpressAPI.getCurrentUser();
    const navUserArea = document.getElementById("navUserArea");
    if (navUserArea) {
      if (user) {
        navUserArea.innerHTML = `
          <div class="user-dropdown" id="userDropdown">
            <div class="user-trigger" onclick="FoodExpress.toggleUserDropdown(event)">
              <div class="user-avatar">${user.name.charAt(0).toUpperCase()}</div>
              <span class="user-name">${user.name.split(' ')[0]}</span>
              <i class="fa-solid fa-chevron-down" style="font-size:0.75rem; color:var(--text-muted)"></i>
            </div>
            <div class="user-dropdown-menu">
              <a href="profile.html" class="dropdown-item"><i class="fa-solid fa-user"></i> My Profile</a>
              <a href="orders.html" class="dropdown-item"><i class="fa-solid fa-box"></i> My Orders</a>
              <a href="favorites.html" class="dropdown-item"><i class="fa-solid fa-heart"></i> Favorites</a>
              <a href="offers.html" class="dropdown-item"><i class="fa-solid fa-tags"></i> Offers & Coupons</a>
              <div class="dropdown-divider"></div>
              <a href="javascript:void(0)" onclick="FoodExpress.handleLogout()" class="dropdown-item" style="color:var(--danger)">
                <i class="fa-solid fa-arrow-right-from-bracket" style="color:var(--danger)"></i> Logout
              </a>
            </div>
          </div>
        `;
      } else {
        navUserArea.innerHTML = `
          <a href="login.html" class="btn btn-outline-primary btn-sm">Login</a>
          <a href="register.html" class="btn btn-primary btn-sm">Sign Up</a>
        `;
      }
    }

    // Sticky nav shadow
    const navbar = document.querySelector(".navbar");
    if (navbar) {
      window.addEventListener("scroll", () => {
        if (window.scrollY > 20) {
          navbar.classList.add("scrolled");
        } else {
          navbar.classList.remove("scrolled");
        }
      });
    }

    // Highlight current page active link
    const currentPath = window.location.pathname.split("/").pop() || "index.html";
    document.querySelectorAll(".nav-link, .mobile-nav-links a, .bottom-nav-item").forEach(link => {
      const href = link.getAttribute("href");
      if (href && (href === currentPath || (currentPath === "" && href === "index.html"))) {
        link.classList.add("active");
      }
    });

    this.updateCartBadge();
  },

  // Toggle user profile dropdown
  toggleUserDropdown(e) {
    e.stopPropagation();
    const dropdown = document.getElementById("userDropdown");
    if (dropdown) dropdown.classList.toggle("open");
  },

  // Close dropdowns on outside click
  setupGlobalClickHandlers() {
    window.addEventListener("click", () => {
      const dropdown = document.getElementById("userDropdown");
      if (dropdown && dropdown.classList.contains("open")) {
        dropdown.classList.remove("open");
      }
    });
  },

  // Toggle Mobile Drawer
  toggleMobileNav(open = true) {
    const drawer = document.getElementById("mobileDrawer");
    const backdrop = document.getElementById("mobileBackdrop");
    if (drawer && backdrop) {
      if (open) {
        drawer.classList.add("open");
        backdrop.classList.add("open");
      } else {
        drawer.classList.remove("open");
        backdrop.classList.remove("open");
      }
    }
  },

  // User Logout
  async handleLogout() {
    await FoodExpressAPI.logout();
    this.toast("info", "Logged Out", "You have been securely logged out.");
    setTimeout(() => {
      window.location.href = "login.html";
    }, 800);
  },

  // Favorites System
  getFavorites() {
    return JSON.parse(localStorage.getItem("fe_favorites") || '{"restaurants":[], "foods":[]}');
  },

  toggleFavorite(type, id, event) {
    if (event) {
      event.preventDefault();
      event.stopPropagation();
    }
    const favs = this.getFavorites();
    const list = favs[type] || [];
    const index = list.indexOf(id);

    if (index > -1) {
      list.splice(index, 1);
      this.toast("info", "Removed from Favorites", "");
    } else {
      list.push(id);
      this.toast("success", "Added to Favorites!", "");
    }

    favs[type] = list;
    localStorage.setItem("fe_favorites", JSON.stringify(favs));

    // Update heart icons on page
    document.querySelectorAll(`.fav-btn[data-type="${type}"][data-id="${id}"]`).forEach(btn => {
      btn.classList.toggle("active", index === -1);
      btn.innerHTML = index === -1 ? '<i class="fa-solid fa-heart"></i>' : '<i class="fa-regular fa-heart"></i>';
    });
  },

  isFavorite(type, id) {
    const favs = this.getFavorites();
    return (favs[type] || []).includes(id);
  },

  // Restaurant Card HTML Generator
  renderRestaurantCard(r) {
    const isFav = this.isFavorite("restaurants", r.id);
    return `
      <div class="restaurant-card" onclick="window.location.href='menu.html?restaurant_id=${r.id}'" style="cursor:pointer">
        <div class="restaurant-img-wrap">
          <img src="${r.image}" alt="${r.name}" class="restaurant-img" onerror="this.src='https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80'">
          ${r.offer ? `<span class="restaurant-badge-offer"><i class="fa-solid fa-badge-percent"></i> ${r.offer}</span>` : ''}
          <button class="fav-btn ${isFav ? 'active' : ''}" data-type="restaurants" data-id="${r.id}" onclick="FoodExpress.toggleFavorite('restaurants', ${r.id}, event)">
            <i class="fa-${isFav ? 'solid' : 'regular'} fa-heart"></i>
          </button>
        </div>
        <div class="restaurant-body">
          <div class="restaurant-header-row">
            <h3 class="restaurant-name">${r.name}</h3>
            <span class="rating-badge"><i class="fa-solid fa-star"></i> ${r.rating || '4.5'}</span>
          </div>
          <p class="restaurant-cuisine">${r.cuisine || 'Multi-Cuisine'}</p>
          <div class="restaurant-meta">
            <div class="restaurant-meta-item">
              <i class="fa-regular fa-clock"></i>
              <span>${r.delivery_time || '25-35 mins'}</span>
            </div>
            <div class="restaurant-meta-item">
              <i class="fa-solid fa-motorcycle"></i>
              <span>${Number(r.delivery_fee) === 0 ? 'Free Delivery' : '₹' + r.delivery_fee}</span>
            </div>
            <div class="restaurant-meta-item" style="margin-left:auto">
              <span class="view-all-link" style="font-size:0.85rem">View Menu <i class="fa-solid fa-chevron-right"></i></span>
            </div>
          </div>
        </div>
      </div>
    `;
  },

  // Food Card HTML Generator
  renderFoodCard(f) {
    const cart = JSON.parse(localStorage.getItem("fe_cart") || "[]");
    const inCart = cart.find(item => item.food_id === f.id);
    const qty = inCart ? inCart.quantity : 0;
    const isVeg = f.is_veg === undefined || Number(f.is_veg) === 1;

    return `
      <div class="food-card" id="foodCard_${f.id}">
        <div class="food-img-wrap" onclick="FoodExpress.openFoodModal(${f.id})" style="cursor:pointer">
          <img src="${f.image}" alt="${f.name}" class="food-img" onerror="this.src='https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80'">
          <span class="veg-badge ${isVeg ? 'veg' : 'non-veg'}"></span>
          <span class="food-rating-pill"><i class="fa-solid fa-star"></i> ${f.rating || '4.7'}</span>
        </div>
        <div class="food-body">
          ${f.restaurant_name ? `<span class="food-restaurant-name">${f.restaurant_name}</span>` : ''}
          <h4 class="food-name" onclick="FoodExpress.openFoodModal(${f.id})" style="cursor:pointer">${f.name}</h4>
          <p class="food-desc">${f.description || 'Delicious freshly prepared dish crafted with premium ingredients.'}</p>
          <div class="food-footer">
            <span class="food-price">₹${f.price}</span>
            <div id="foodBtnContainer_${f.id}">
              ${qty > 0 ? `
                <div class="qty-control">
                  <button class="qty-btn" onclick="FoodExpressCart.updateQuantity(${f.id}, -1)">-</button>
                  <span class="qty-val">${qty}</span>
                  <button class="qty-btn" onclick="FoodExpressCart.updateQuantity(${f.id}, 1)">+</button>
                </div>
              ` : `
                <button class="btn btn-primary btn-sm" onclick="FoodExpress.openFoodModal(${f.id})">
                  <i class="fa-solid fa-plus"></i> Add
                </button>
              `}
            </div>
          </div>
        </div>
      </div>
    `;
  },

  // Open Interactive Food Details & Customization Modal
  async openFoodModal(foodId) {
    const allFoods = await FoodExpressAPI.getFoods();
    const food = allFoods.find(item => Number(item.id) === Number(foodId));
    if (!food) return;

    let modal = document.getElementById("foodDetailsModal");
    if (!modal) {
      modal = document.createElement("div");
      modal.id = "foodDetailsModal";
      modal.className = "modal-backdrop";
      document.body.appendChild(modal);
    }

    const isVeg = food.is_veg === undefined || Number(food.is_veg) === 1;

    modal.innerHTML = `
      <div class="modal-dialog">
        <div class="modal-header">
          <div style="display:flex; align-items:center; gap:8px">
            <span class="veg-badge ${isVeg ? 'veg' : 'non-veg'}" style="position:static"></span>
            <h3 style="font-size:1.25rem">${food.name}</h3>
          </div>
          <button class="modal-close-btn" onclick="FoodExpress.closeFoodModal()">&times;</button>
        </div>
        <div class="modal-body">
          <img src="${food.image}" alt="${food.name}" style="width:100%; height:220px; object-fit:cover; border-radius:var(--radius-md); margin-bottom:16px" onerror="this.src='https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80'">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px">
            <span style="font-size:1.5rem; font-weight:800; color:var(--primary)">₹<span id="modalFoodPrice">${food.price}</span></span>
            <span class="rating-badge"><i class="fa-solid fa-star"></i> ${food.rating || '4.7'} (200+ ratings)</span>
          </div>
          <p style="margin-bottom:20px; font-size:0.92rem; color:var(--text-muted)">${food.description || 'Special recipe created with fresh garden spices and cooked to order.'}</p>

          <div class="customization-group">
            <h4 class="customization-title">Select Portion Size</h4>
            <label class="custom-option-label">
              <span><input type="radio" name="portionSize" value="0" checked onchange="FoodExpress.calcModalPrice(${food.price})"> Regular</span>
              <span style="font-weight:600">Base</span>
            </label>
            <label class="custom-option-label">
              <span><input type="radio" name="portionSize" value="60" onchange="FoodExpress.calcModalPrice(${food.price})"> Large (Serves 2)</span>
              <span style="font-weight:600">+₹60</span>
            </label>
          </div>

          <div class="customization-group">
            <h4 class="customization-title">Add-ons & Toppings</h4>
            <label class="custom-option-label">
              <span><input type="checkbox" class="modal-addon" value="40" onchange="FoodExpress.calcModalPrice(${food.price})"> Extra Cheese Layer</span>
              <span style="font-weight:600">+₹40</span>
            </label>
            <label class="custom-option-label">
              <span><input type="checkbox" class="modal-addon" value="30" onchange="FoodExpress.calcModalPrice(${food.price})"> Crispy Herb Crunch / Dips</span>
              <span style="font-weight:600">+₹30</span>
            </label>
          </div>

          <div class="customization-group">
            <h4 class="customization-title">Special Cooking Request</h4>
            <textarea id="modalSpecialNotes" rows="2" class="form-input no-icon" placeholder="E.g., Less spicy, no onions, extra napkins..."></textarea>
          </div>
        </div>
        <div class="modal-footer" style="justify-content:space-between">
          <div class="qty-control" style="border-radius:var(--radius-full)">
            <button class="qty-btn" onclick="FoodExpress.adjustModalQty(-1)">-</button>
            <span class="qty-val" id="modalQty">1</span>
            <button class="qty-btn" onclick="FoodExpress.adjustModalQty(1)">+</button>
          </div>
          <button class="btn btn-primary" onclick="FoodExpress.addCustomizedItemToCart(${JSON.stringify(food).replace(/"/g, '&quot;')})">
            Add to Cart • ₹<span id="modalBtnTotal">${food.price}</span>
          </button>
        </div>
      </div>
    `;

    modal.classList.add("open");
  },

  calcModalPrice(basePrice) {
    let price = Number(basePrice);
    const sizeRadio = document.querySelector('input[name="portionSize"]:checked');
    if (sizeRadio) price += Number(sizeRadio.value);

    document.querySelectorAll(".modal-addon:checked").forEach(addon => {
      price += Number(addon.value);
    });

    const qty = Number(document.getElementById("modalQty").textContent || 1);
    const total = price * qty;

    const priceEl = document.getElementById("modalFoodPrice");
    if (priceEl) priceEl.textContent = price;
    const btnTotal = document.getElementById("modalBtnTotal");
    if (btnTotal) btnTotal.textContent = total;
  },

  adjustModalQty(delta) {
    const qtyEl = document.getElementById("modalQty");
    if (!qtyEl) return;
    let qty = Math.max(1, Number(qtyEl.textContent) + delta);
    qtyEl.textContent = qty;
    const base = Number(document.getElementById("modalFoodPrice").textContent);
    document.getElementById("modalBtnTotal").textContent = base * qty;
  },

  closeFoodModal() {
    const modal = document.getElementById("foodDetailsModal");
    if (modal) modal.classList.remove("open");
  },

  addCustomizedItemToCart(food) {
    const sizeRadio = document.querySelector('input[name="portionSize"]:checked');
    const sizeText = sizeRadio && sizeRadio.value > 0 ? "Large" : "Regular";
    const addons = [];
    document.querySelectorAll(".modal-addon:checked").forEach(cb => {
      addons.push(cb.parentElement.textContent.trim().split('+')[0].trim());
    });
    const notes = document.getElementById("modalSpecialNotes").value.trim();
    const qty = Number(document.getElementById("modalQty").textContent || 1);
    const unitPrice = Number(document.getElementById("modalFoodPrice").textContent);

    FoodExpressCart.addItem({
      food_id: food.id,
      name: food.name,
      price: unitPrice,
      image: food.image,
      restaurant_id: food.restaurant_id,
      restaurant_name: food.restaurant_name || "FoodExpress",
      quantity: qty,
      size: sizeText,
      addons: addons.join(", "),
      notes: notes
    });

    this.closeFoodModal();
    this.toast("success", "Added to Cart!", `${qty}x ${food.name} added to your order.`);
  }
};

// Initialize shared features on DOM load
document.addEventListener("DOMContentLoaded", () => {
  FoodExpress.setupNavbar();
  FoodExpress.setupGlobalClickHandlers();
});
