CREATE DATABASE IF NOT EXISTS online_food_order;
USE online_food_order;

DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS foods;
DROP TABLE IF EXISTS restaurants;
DROP TABLE IF EXISTS coupons;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE restaurants (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    cuisine VARCHAR(150) DEFAULT 'Multi-Cuisine',
    rating DECIMAL(3,1) DEFAULT 4.5,
    reviews_count INT DEFAULT 420,
    delivery_time VARCHAR(50) DEFAULT '25-35 mins',
    delivery_fee DECIMAL(10,2) DEFAULT 30.00,
    offer VARCHAR(100) DEFAULT '50% OFF up to ₹100',
    image VARCHAR(500),
    is_featured TINYINT(1) DEFAULT 1,
    status VARCHAR(30) DEFAULT 'Open',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE foods (
    id INT AUTO_INCREMENT PRIMARY KEY,
    restaurant_id INT NOT NULL,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    category VARCHAR(80),
    image VARCHAR(500),
    rating DECIMAL(3,1) DEFAULT 4.7,
    is_veg TINYINT(1) DEFAULT 1,
    is_popular TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (restaurant_id) REFERENCES restaurants(id) ON DELETE CASCADE
);

CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total DECIMAL(10,2) NOT NULL,
    status VARCHAR(40) DEFAULT 'Pending',
    delivery_address TEXT NOT NULL,
    payment_method VARCHAR(50) DEFAULT 'Credit/Debit Card',
    coupon_code VARCHAR(50) DEFAULT NULL,
    discount DECIMAL(10,2) DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    food_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (food_id) REFERENCES foods(id) ON DELETE CASCADE
);

CREATE TABLE coupons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(50) NOT NULL UNIQUE,
    discount_percent INT DEFAULT 0,
    discount_amount DECIMAL(10,2) DEFAULT 0.00,
    min_order DECIMAL(10,2) DEFAULT 0.00,
    description VARCHAR(255),
    expires_at DATE DEFAULT '2027-12-31'
);

-- Seed Restaurants
INSERT INTO restaurants (id, name, description, cuisine, rating, reviews_count, delivery_time, delivery_fee, offer, image, is_featured, status) VALUES
(1, 'Spice Garden', 'Authentic North Indian, rich curries, fragrant tandoor breads & dum biryanis.', 'North Indian, Mughlai', 4.8, 1420, '25-35 mins', 0.00, '50% OFF up to ₹100', 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80', 1, 'Open'),
(2, 'Pizza House', 'Handcrafted stone-baked pizzas, cheesy garlic breads and classic Italian pastas.', 'Italian, Pizza, Fast Food', 4.7, 980, '20-30 mins', 25.00, '40% OFF with FE40', 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=800&q=80', 1, 'Open'),
(3, 'Burger Point', 'Gourmet smashed burgers, crispy french fries, thick shakes and loaded snacks.', 'American, Burgers, Shakes', 4.6, 850, '15-25 mins', 0.00, 'FREE Fries on ₹299+', 'https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=800&q=80', 1, 'Open'),
(4, 'Royal Biryani Darbar', 'Traditional Dum Biryanis cooked with pure ghee, saffron and aged basmati rice.', 'Biryani, Mughlai, Kebabs', 4.9, 2100, '30-40 mins', 30.00, 'FLAT ₹125 OFF', 'https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=800&q=80', 1, 'Open'),
(5, 'The Wok Express', 'Sizzling wok-tossed noodles, spicy schezwan gravies, dim sums & pan-Asian bowls.', 'Chinese, Asian, Thai', 4.5, 620, '25-35 mins', 20.00, '30% OFF up to ₹75', 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&w=800&q=80', 1, 'Open'),
(6, 'Sweet Treats Bakery', 'Decadent chocolate cakes, warm brownies, fresh pastries and artisan desserts.', 'Desserts, Bakery, Cakes', 4.9, 1310, '20-30 mins', 0.00, 'Buy 1 Get 1 Dessert', 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=800&q=80', 1, 'Open'),
(7, 'Green Bowl Healthy Cafe', 'Wholesome organic salads, protein grain bowls, cold-pressed juices and acai.', 'Healthy, Salads, Vegan', 4.7, 440, '20-30 mins', 15.00, '20% OFF Healthy Eats', 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=800&q=80', 1, 'Open'),
(8, 'Cafe Mocha & Sips', 'Specialty espresso coffee, creamy cold brews, milkshakes and warm sandwiches.', 'Cafe, Beverages, Sandwiches', 4.6, 730, '15-25 mins', 0.00, 'Flat ₹50 OFF', 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=800&q=80', 1, 'Open');

-- Seed Foods
INSERT INTO foods (restaurant_id, name, description, price, category, image, rating, is_veg, is_popular) VALUES
-- Spice Garden (Restaurant 1)
(1, 'Paneer Butter Masala', 'Fresh cottage cheese cubes simmered in a luscious buttery tomato and cashew gravy.', 240.00, 'Main Course', 'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=800&q=80', 4.9, 1, 1),
(1, 'Dal Makhani', 'Slow cooked black lentils simmered overnight with butter, fresh cream and aromatic spices.', 210.00, 'Main Course', 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80', 4.8, 1, 1),
(1, 'Butter Garlic Naan', 'Clay-oven baked fluffy flatbread glazed with melted salted butter and roasted garlic.', 60.00, 'Starters', 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=800&q=80', 4.7, 1, 0),
(1, 'Paneer Tikka Platter', 'Marinated cottage cheese and bell peppers char-grilled in traditional tandoor.', 280.00, 'Starters', 'https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format&fit=crop&w=800&q=80', 4.9, 1, 1),
(1, 'Masala Dosa', 'Crispy fermented crepe stuffed with spiced potato filling, served with coconut chutney and sambar.', 120.00, 'Starters', 'https://images.unsplash.com/photo-1668236543090-82eba5ee5976?auto=format&fit=crop&w=800&q=80', 4.8, 1, 1),

-- Pizza House (Restaurant 2)
(2, 'Margherita Classico Pizza', 'San Marzano tomato sauce, fresh mozzarella pearls, sweet basil and extra virgin olive oil.', 299.00, 'Pizza', 'https://images.unsplash.com/photo-1574071318508-1cdbab80d002?auto=format&fit=crop&w=800&q=80', 4.8, 1, 1),
(2, 'Farmhouse Garden Pizza', 'Loaded with crisp bell peppers, red onions, juicy mushrooms, sweet corn and mozzarella.', 359.00, 'Pizza', 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=800&q=80', 4.7, 1, 1),
(2, 'Pepperoni Feast Pizza', 'Zesty spiced pepperoni slices, double mozzarella cheese, and secret Italian herb blend.', 429.00, 'Pizza', 'https://images.unsplash.com/photo-1534308983496-4fabb1a015ee?auto=format&fit=crop&w=800&q=80', 4.9, 0, 1),
(2, 'Cheesy Stuffed Garlic Bread', 'Golden toasted pull-apart bread loaded with melted mozzarella, roasted garlic butter and oregano.', 169.00, 'Starters', 'https://images.unsplash.com/photo-1619895092538-128341789043?auto=format&fit=crop&w=800&q=80', 4.8, 1, 1),
(2, 'Creamy Alfredo Pasta', 'Penne pasta tossed in a velvety parmesan cream sauce with sauteed broccoli and herbs.', 279.00, 'Main Course', 'https://images.unsplash.com/photo-1621996346565-e3d5d6281745?auto=format&fit=crop&w=800&q=80', 4.6, 1, 0),

-- Burger Point (Restaurant 3)
(3, 'Classic Cheeseburger', 'Juicy grilled patty topped with aged cheddar cheese, crisp lettuce, tomato, pickles & secret sauce.', 220.00, 'Burgers', 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=80', 4.8, 0, 1),
(3, 'Crispy Veg Supreme Burger', 'Spiced golden vegetable patty, creamy mayo, fresh lettuce and slice of cheddar on toasted sesame bun.', 179.00, 'Burgers', 'https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=800&q=80', 4.7, 1, 1),
(3, 'Smoky BBQ Bacon Burger', 'Double patty stacked with crispy smoked bacon, onion rings, cheddar and sweet hickory BBQ sauce.', 289.00, 'Burgers', 'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?auto=format&fit=crop&w=800&q=80', 4.9, 0, 1),
(3, 'Peri Peri Seasoned Fries', 'Crisp skin-on golden potatoes dusted with spicy African bird-eye chili seasoning.', 129.00, 'Starters', 'https://images.unsplash.com/photo-1576107232684-1279f3908594?auto=format&fit=crop&w=800&q=80', 4.6, 1, 1),

-- Royal Biryani Darbar (Restaurant 4)
(4, 'Royal Chicken Dum Biryani', 'Marinated tender chicken slow-cooked with basmati rice, saffron, fried onions and royal spices.', 340.00, 'Main Course', 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=800&q=80', 4.9, 0, 1),
(4, 'Nizami Veg Dum Biryani', 'Medley of fresh garden vegetables, paneer cubes, and aromatic saffron rice sealed in clay handi.', 260.00, 'Main Course', 'https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=800&q=80', 4.8, 1, 1),
(4, 'Chicken Seekh Kebab', 'Minced spiced chicken skewers roasted in tandoor with fresh mint and cilantro dip.', 290.00, 'Starters', 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format&fit=crop&w=800&q=80', 4.8, 0, 1),
(4, 'Shahi Mirchi Ka Salan', 'Traditional Hyderabadi spicy chili and peanut curry made to pair with biryani.', 99.00, 'Starters', 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=800&q=80', 4.5, 1, 0),

-- The Wok Express (Restaurant 5)
(5, 'Chili Garlic Hakka Noodles', 'Wok-tossed noodles with shredded cabbage, carrots, bell peppers, garlic and chili sauce.', 199.00, 'Main Course', 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&w=800&q=80', 4.7, 1, 1),
(5, 'Veg Manchurian Gravy', 'Crisp vegetable dumplings simmered in dark savory soya, coriander and ginger gravy.', 219.00, 'Main Course', 'https://images.unsplash.com/photo-1541696432-82c6da8ce7bf?auto=format&fit=crop&w=800&q=80', 4.6, 1, 1),
(5, 'Steamed Dim Sum Platter', 'Delicate steamed dumplings stuffed with water chestnuts, corn, mushroom and spicy dip.', 229.00, 'Starters', 'https://images.unsplash.com/photo-1579871494447-9811cf80d66c?auto=format&fit=crop&w=800&q=80', 4.8, 1, 1),

-- Sweet Treats Bakery (Restaurant 6)
(6, 'Belgian Dark Chocolate Cake', 'Moist layers of rich chocolate sponge filled with velvety ganache and chocolate curls.', 180.00, 'Desserts', 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=800&q=80', 4.9, 1, 1),
(6, 'Warm Fudgy Walnut Brownie', 'Chewy dark cocoa brownie with toasted walnuts, served great with vanilla ice cream.', 140.00, 'Desserts', 'https://images.unsplash.com/photo-1551024601-bec78aea704b?auto=format&fit=crop&w=800&q=80', 4.9, 1, 1),
(6, 'New York Baked Cheesecake', 'Classic creamy cheesecake on a buttery graham cracker crust with berry compote.', 220.00, 'Desserts', 'https://images.unsplash.com/photo-1533134242443-d4fd215305ad?auto=format&fit=crop&w=800&q=80', 4.8, 1, 1),
(6, 'Red Velvet Cupcake Duo', 'Fluffy crimson cupcakes with rich vanilla bean cream cheese frosting swirl.', 130.00, 'Desserts', 'https://images.unsplash.com/photo-1587314168485-3236d6710814?auto=format&fit=crop&w=800&q=80', 4.7, 1, 0),

-- Green Bowl Healthy Cafe (Restaurant 7)
(7, 'Mediterranean Falafel Bowl', 'Crispy falafels, hummus, quinoa, cucumber, cherry tomatoes, olives and tahini drizzle.', 260.00, 'Main Course', 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=800&q=80', 4.8, 1, 1),
(7, 'Avocado Crunch Salad', 'Fresh Hass avocado slices, baby spinach, roasted pumpkin seeds, and citrus vinaigrette.', 240.00, 'Starters', 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=800&q=80', 4.7, 1, 1),
(7, 'Tropical Green Detox Smoothie', 'Blended kale, green apple, cucumber, mint, ginger and tender coconut water.', 149.00, 'Beverages', 'https://images.unsplash.com/photo-1544145945-f90425340c7e?auto=format&fit=crop&w=800&q=80', 4.6, 1, 0),

-- Cafe Mocha & Sips (Restaurant 8)
(8, 'Iced Caramel Frappe', 'Chilled espresso blended with milk, sweet caramel syrup, topped with whipped cream.', 180.00, 'Beverages', 'https://images.unsplash.com/photo-1572490122747-3968b75cc699?auto=format&fit=crop&w=800&q=80', 4.8, 1, 1),
(8, 'Hazelnut Cappuccino', 'Rich double espresso shot, steamed micro-foam milk and roasted hazelnut syrup.', 150.00, 'Beverages', 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=800&q=80', 4.7, 1, 0),
(8, 'Oreo Overload Thick Shake', 'Crushed oreo cookies blended with creamy dairy ice cream and rich chocolate fudge.', 190.00, 'Beverages', 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=800&q=80', 4.9, 1, 1);

-- Seed Users (Demo password is: demo123 or password)
INSERT INTO users (id, name, email, password, phone, address) VALUES
(1, 'Demo User', 'demo@example.com', '$2y$10$7QZevPq6t2AUDzRIejm.BO52B295858BYpdUZEzOnmFQSEZEdiTa2', '9876543210', 'Flat 402, Green Valley Heights, MG Road, Bangalore');

-- Seed Coupons
INSERT INTO coupons (code, discount_percent, discount_amount, min_order, description) VALUES
('FOOD50', 50, 100.00, 199.00, '50% OFF up to ₹100 on orders above ₹199'),
('FREEDEL', 0, 30.00, 149.00, 'Free delivery on delicious orders above ₹149'),
('WELCOME100', 0, 100.00, 299.00, 'Flat ₹100 OFF for our lovely new foodies');

-- Seed Sample Orders
INSERT INTO orders (id, user_id, total, status, delivery_address, payment_method, coupon_code, discount) VALUES
(1001, 1, 480.00, 'Delivered', 'Flat 402, Green Valley Heights, MG Road, Bangalore', 'UPI', 'FOOD50', 50.00),
(1002, 1, 629.00, 'Out for Delivery', 'Flat 402, Green Valley Heights, MG Road, Bangalore', 'Credit/Debit Card', 'FREEDEL', 30.00),
(1003, 1, 399.00, 'Preparing', 'Flat 402, Green Valley Heights, MG Road, Bangalore', 'Cash on Delivery', NULL, 0.00);

-- Seed Order Items
INSERT INTO order_items (order_id, food_id, quantity, price) VALUES
(1001, 1, 2, 240.00),
(1002, 6, 1, 299.00),
(1002, 7, 1, 359.00),
(1003, 11, 1, 220.00),
(1003, 14, 1, 129.00);
